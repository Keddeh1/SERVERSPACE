package com.example

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.security.MessageDigest

@Serializable
data class HciObject(val id: String, val type: String, val state: String)

@Serializable
data class OntologyNode(val id: String, val concept: String, val implementation: String)

class HciGatewayService {
    private var v3State = BrainkV3State()
    private val proofLedger = mutableListOf<String>()
    
    private val objectRegistry = mutableMapOf<String, HciObject>()
    private val ontologyMap = mutableListOf<OntologyNode>()

    init {
        // Seed ontology
        ontologyMap.add(OntologyNode("05_01", "OPERATING", "RUNTIME_MESH"))
        ontologyMap.add(OntologyNode("05_02", "CALIBRATION", "ZERO_TO_ONE_GATE"))
    }

    fun getV3Status(): BrainkV3State = v3State

    fun rehydrate(newState: BrainkV3State) {
        v3State = newState
        proofLedger.add("SYSTEM_REHYDRATED: AUTH=${newState.auth} | SYMBOLS=${newState.symbolsParsed}")
    }

    fun ingestSymbol(symbol: String): BrainkV3State {
        val calibration = KexV3Calibrator.calibrate(symbol)
        val newSymbolsParsed = v3State.symbolsParsed + 1
        val newZeroGlyphs = if (calibration == 0) v3State.zeroGlyphsSeen + 1 else v3State.zeroGlyphsSeen
        
        v3State = v3State.copy(
            symbolsParsed = newSymbolsParsed,
            zeroGlyphsSeen = newZeroGlyphs,
            textStateHash = calculateStateHash(symbol)
        )
        return v3State
    }

    fun submitClaim(claim: String, evidence: String): Boolean {
        val accepted = KexV3Calibrator.verifyClaim(evidence, v3State.activeBoundary)
        v3State = v3State.copy(lastClaimAccepted = accepted)
        if (accepted) {
            proofLedger.add("CLAIM_VERIFIED: $claim | EVIDENCE: $evidence")
        }
        return accepted
    }

    fun queryKnowledge(query: String): List<OntologyNode> {
        return ontologyMap.filter { it.concept.contains(query, ignoreCase = true) }
    }

    private fun calculateStateHash(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(input.toByteArray())
        return hash.joinToString("") { "%02x".format(it) }
    }
}
