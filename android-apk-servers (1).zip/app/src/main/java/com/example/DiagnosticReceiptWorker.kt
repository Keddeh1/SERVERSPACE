package com.example

import android.content.Context
import android.os.StatFs
import androidx.room.Room
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.AppDatabase
import com.example.data.DiagnosticReceipt
import com.example.data.ProvenanceType
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.UUID

class DiagnosticReceiptWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val startNs = System.nanoTime()
        return try {
            val db = Room.databaseBuilder(
                applicationContext,
                AppDatabase::class.java, "kex-database"
            ).build()
            val dao = db.diagnosticReceiptDao()

            // 1. Mechanical SQLite integrity check
            val sqliteDb = db.openHelper.readableDatabase
            var sqliteCheckOk = false
            var sqliteMessage = ""
            val cursor = sqliteDb.query("PRAGMA quick_check;")
            if (cursor.moveToFirst()) {
                val pragmaResult = cursor.getString(0)
                sqliteCheckOk = pragmaResult.equals("ok", ignoreCase = true)
                sqliteMessage = pragmaResult
            }
            cursor.close()

            // 2. Mechanical Storage Canary write/read/hash check
            var canaryOk = false
            var canaryHash = ""
            val canaryFile = File(applicationContext.filesDir, "canary_worker_${UUID.randomUUID()}.tmp")
            val stat = StatFs(applicationContext.filesDir.path)
            val freeBytes = stat.availableBytes
            val totalBytes = stat.totalBytes

            try {
                val testBytes = ByteArray(32) { (it + 42).toByte() }
                canaryFile.writeBytes(testBytes)

                val readBack = canaryFile.readBytes()
                val md = MessageDigest.getInstance("SHA-256")
                canaryHash = md.digest(readBack).joinToString("") { "%02x".format(it) }

                canaryOk = (canaryFile.length() == testBytes.size.toLong()) && 
                           (readBack.contentEquals(testBytes)) && 
                           (freeBytes > 0)
            } finally {
                if (canaryFile.exists()) canaryFile.delete()
            }

            val executionDurationNs = System.nanoTime() - startNs

            // 3. Epistemic Provenance Rule: ONLY mark EMPIRICALLY_VERIFIED if both checks genuinely passed
            val isVerified = sqliteCheckOk && canaryOk
            val provenance = if (isVerified) ProvenanceType.EMPIRICALLY_VERIFIED else ProvenanceType.DECLARED

            val receiptPayload = JSONObject().apply {
                put("sqlite_integrity", sqliteMessage)
                put("sqlite_check_ok", sqliteCheckOk)
                put("canary_ok", canaryOk)
                put("canary_sha256", canaryHash)
                put("storage_free_bytes", freeBytes)
                put("storage_total_bytes", totalBytes)
                put("duration_ns", executionDurationNs)
                put("timestamp_ms", System.currentTimeMillis())
            }

            val receipt = DiagnosticReceipt(
                taskId = id.toString(),
                resultData = receiptPayload.toString(),
                provenanceId = provenance
            )

            dao.insertReceipt(receipt)

            if (isVerified) Result.success() else Result.retry()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
