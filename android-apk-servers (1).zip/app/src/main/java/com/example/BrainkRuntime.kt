package com.example

import java.security.MessageDigest
import kotlin.math.floor
import kotlin.math.log10

class BrainkRuntime(var key: Long = 4696753037434160968L) {
    var bootState = "OFFLINE"
    var triStateHiz = true
    var pllLock = false
    var wpLineActive = false
    var systemFreqHz = 0.0
    var siliconAnchorHash: String? = null
    
    // V3 Calibrated State
    var v3Auth = "4696752002360214856"
    var unitFloor = 1
    var symbolsParsed = 0
    var zeroGlyphsSeen = 0
    var textStateHash = ""

    val lanes = mutableMapOf("MATH" to 0L, "LEDGER" to 0L, "CODE" to 0L)
    var taskEnvelope: MutableMap<String, Any>? = null
    var obligationLedger = mutableListOf<MutableMap<String, Any>>()
    val skills = mutableMapOf<String, MutableMap<String, Any>>()

    fun extractSeedParameters(): Map<String, Any> {
        val hexStr = String.format("%016x", key)
        val byteArray = IntArray(8)
        for (i in 0 until 8) {
            byteArray[i] = hexStr.substring(i * 2, i * 2 + 2).toInt(16)
        }
        val version = "${byteArray[0].toChar()}${byteArray[1].toChar()}${byteArray[2].toChar()}"
        val bypassIndex = byteArray[6]
        val anchor = "${byteArray[7].toChar()}"
        
        val floatVal = Double.fromBits(key)
        
        return mapOf(
            "version" to version,
            "bypass_index" to bypassIndex,
            "anchor" to anchor,
            "float_val" to floatVal,
            "byte_array" to byteArray
        )
    }
    
    fun executeVfd(): Map<String, Any> {
        val params = extractSeedParameters()
        val version = params["version"] as String
        val bypassIndex = params["bypass_index"] as Int
        val anchor = params["anchor"] as String
        val floatVal = params["float_val"] as Double
        val byteArray = params["byte_array"] as IntArray
        
        if (version != "A.8" || bypassIndex != 7 || anchor != "H") {
            bootState = "BOOT_FAULT"
            throw IllegalArgumentException("Boot signature mismatch: $version, index $bypassIndex, anchor '$anchor'")
        }
        
        lanes["MATH"] = (byteArray[7] - 64).toLong()
        lanes["LEDGER"] = 1L
        lanes["CODE"] = floor(floatVal / 10000).toLong()
        
        val nMax = 10000
        val bypass = bypassIndex
        
        var logP = 0.0
        for (k in 2..nMax) {
            logP += log10(k.toDouble())
        }
        logP -= log10((bypass + 1).toDouble())
        
        val mathLen = floor(log10(lanes["MATH"]!!.toDouble()) + logP).toInt() + 1
        val ledgerLen = floor(log10(lanes["LEDGER"]!!.toDouble()) + logP).toInt() + 1
        val codeLen = floor(log10(lanes["CODE"]!!.toDouble()) + logP).toInt() + 1
        
        val finalStrandLength = (mathLen + ledgerLen + codeLen) - 3
        
        if (finalStrandLength != 106977) {
            bootState = "VALIDATION_FAULT"
            throw IllegalArgumentException("Integrity check failed. Output strand is $finalStrandLength digits, target is 106,977.")
        }
        
        lanes["MATH"] = lanes["MATH"]!! * -1
        lanes["LEDGER"] = lanes["LEDGER"]!! * -1
        lanes["CODE"] = lanes["CODE"]!! * -1
        
        val stateSignature = "${lanes["MATH"]}:${lanes["LEDGER"]}:${lanes["CODE"]}:$finalStrandLength"
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(stateSignature.toByteArray(Charsets.UTF_8))
        siliconAnchorHash = digest.joinToString("") { "%02x".format(it) }
        
        bootState = "ACTIVE_RUNTIME"
        pllLock = true
        systemFreqHz = 106977.0
        wpLineActive = true
        
        return mapOf(
            "math_len" to mathLen,
            "ledger_len" to ledgerLen,
            "code_len" to codeLen,
            "strand_len" to finalStrandLength,
            "silicon_hash" to siliconAnchorHash!!
        )
    }
    
    fun wireEnclaves(taskId: String, goal: String, obligations: List<String>) {
        if (bootState != "ACTIVE_RUNTIME") {
            throw IllegalStateException("Bus write blocked: System registers must be IGNITED first.")
        }
        
        taskEnvelope = mutableMapOf(
            "ID" to taskId,
            "Goal" to goal,
            "WP_LOCK" to true
        )
        
        obligationLedger.clear()
        obligations.forEachIndexed { idx, o ->
            obligationLedger.add(mutableMapOf(
                "irq" to (idx + 1),
                "obligation" to o,
                "status" to "OPEN"
            ))
        }
        
        skills.clear()
        triStateHiz = true
    }
    
    fun isBusSevered(): Boolean {
        return bootState == "HALTED" || (triStateHiz && !pllLock && bootState == "ACTIVE_RUNTIME")
    }
    
    fun processInput(payload: String): Map<String, Any> {
        if (bootState != "ACTIVE_RUNTIME") {
            return mapOf("status" to "HALTED", "message" to "Processor is offline.")
        }
        if (isBusSevered()) {
            return mapOf("status" to "Hi-Z_ISOLATED", "message" to "Tri-state bus is severed. Execution blocked.")
        }

        // V3 Calibration Law: external 0-like symbol may be observed but not baseline
        symbolsParsed++
        if (payload.contains("0") || payload.isBlank()) {
            zeroGlyphsSeen++
        }
        
        val digest = MessageDigest.getInstance("SHA-256")
        textStateHash = digest.digest(payload.toByteArray()).joinToString("") { "%02x".format(it) }
        
        val payloadLower = payload.lowercase()
        val driftMargin = if (payloadLower.contains("recursive learning") || payloadLower.contains("tangent")) 0.85 else 0.0
        
        if (driftMargin > 0.10) {
            pllLock = false
            triStateHiz = true
            bootState = "HALTED"
            return mapOf(
                "status" to "CRITICAL_HALT",
                "drift_percentage" to String.format("%.2f%%", driftMargin * 100),
                "message" to "Semantic drift exceeded tolerance limit. Tri-state bus severed. System halted."
            )
        }
        
        val openIrqs = obligationLedger.count { it["status"] == "OPEN" }
        
        return mapOf(
            "status" to "RUNNING",
            "drift_percentage" to String.format("%.2f%%", driftMargin * 100),
            "active_goal" to (taskEnvelope?.get("Goal") ?: ""),
            "open_irqs" to openIrqs,
            "pll_lock" to pllLock,
            "v3_auth" to v3Auth,
            "symbols_parsed" to symbolsParsed,
            "zero_glyphs_seen" to zeroGlyphsSeen
        )
    }
    
    fun admitCapability(name: String, seed: String, expectedHash: String): Map<String, Any> {
        if (isBusSevered()) {
            return mapOf("status" to "Hi-Z_ISOLATED", "message" to "Bus is severed. Cannot admit capabilities.")
        }
        
        val reconstructedBytecode = "COMP_RECON_${seed}_$name"
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(reconstructedBytecode.toByteArray(Charsets.UTF_8))
        val computedHash = digest.joinToString("") { "%02x".format(it) }.substring(0, 10)
        
        if (computedHash != expectedHash) {
            triStateHiz = true
            bootState = "HALTED"
            return mapOf(
                "status" to "VALIDATION_FAIL",
                "message" to "Cryptographic integrity failed for capability '$name'. Execution bus halted."
            )
        }
        
        skills[name] = mutableMapOf("status" to "ACTIVE", "hash" to computedHash)
        return mapOf(
            "status" to "ADMITTED",
            "capability" to name,
            "hash" to computedHash,
            "tri_state_hiz" to false
        )
    }
}
