package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Custom BRAINK Colors
val DarkBackground = Color(0xFF0F1115)
val GlassBackground = Color(0x1AFFFFFF) // white/10
val GlassBorder = Color(0x1AFFFFFF) // white/10
val GlassUserBackground = Color(0x4D2563EB) // blue-600/30
val GlassUserBorder = Color(0x4D60A5FA) // blue-400/30

val TextPrimary = Color(0xFFE2E8F0) // slate-200
val TextMuted = Color(0xFF64748B) // slate-500
val AccentBlue = Color(0xFF60A5FA) // blue-400
val AccentPurple = Color(0xFFC084FC) // purple-400
