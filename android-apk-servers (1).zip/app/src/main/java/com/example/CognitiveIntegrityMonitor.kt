package com.example

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import org.json.JSONObject
import org.json.JSONArray

class CognitiveIntegrityMonitor(
    private val runtime: BrainkRuntime
) {
    private val _validationEvents = MutableSharedFlow<String>()
    val validationEvents = _validationEvents.asSharedFlow()

    private var validatorJob: Job? = null
    
    // Track the expected baseline hash once boot completes
    private var expectedBaselineHash: String? = null

    fun startValidationLoop(scope: CoroutineScope) {
        if (validatorJob != null) return
        validatorJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(30000) // Periodic monitor
                performValidation()
            }
        }
    }

    fun forceValidation() {
        CoroutineScope(Dispatchers.Default).launch {
            performValidation()
        }
    }
    
    private suspend fun performValidation() {
        if (expectedBaselineHash == null && runtime.siliconAnchorHash != null) {
            expectedBaselineHash = runtime.siliconAnchorHash
        }
        
        val seedJson = JSONObject().apply {
            put("K_ID", "KEX_SEED_A8_COGNITIVE_INTEGRITY")
            
            val projections = JSONObject().apply {
                put("U_H", if (runtime.key != 0L) runtime.key.toString() else "4696753037434160968")
                
                val bhArray = JSONArray()
                for (i in 0..6) bhArray.put(i)
                
                val expectedMath = runtime.lanes["MATH"] ?: 1024L
                bhArray.put(expectedMath + 64)
                put("B_H", bhArray)
                
                val expectedCode = runtime.lanes["CODE"] ?: 1024L
                put("F_64_H", expectedCode * 10000.0)
            }
            put("Projections", projections)
            
            val taskEnvelope = JSONObject().apply {
                put("ID", "VALIDATION-LOOP-01")
                put("Goal", "Cognitive integrity preservation")
            }
            put("Task_Envelope", taskEnvelope)
            
            val obligations = JSONArray().apply {
                put(JSONObject().apply { put("description", "Execute cognitive integrity hash verification") })
            }
            put("Obligations", obligations)
        }
        
        try {
            SeedUnpacker.unpack(seedJson.toString(), runtime)
            
            if (expectedBaselineHash != null && runtime.siliconAnchorHash != expectedBaselineHash) {
                // DRIFT DETECTED
                val alert = """
                    [!] COGNITIVE DRIFT DETECTED
                    - Expected Hash: ${expectedBaselineHash}
                    - Current Hash: ${runtime.siliconAnchorHash}
                    - ACTION: Resetting Memory Lanes to baseline parameters to preserve cognitive integrity.
                """.trimIndent()
                
                // Reset to baseline
                runtime.lanes["MATH"] = 1024L
                runtime.lanes["LEDGER"] = 1L
                runtime.lanes["CODE"] = 1024L
                runtime.executeVfd() // Lock it back in
                expectedBaselineHash = runtime.siliconAnchorHash
                
                CoroutineScope(Dispatchers.Main).launch {
                    _validationEvents.emit(alert)
                }
            } else {
                val alert = """
                    [✓] COGNITIVE INTEGRITY VALIDATED
                    - Seed Unpacker Utility Triggered.
                    - VFD Sequence Re-executed.
                    - Hash Confirmed: ${runtime.siliconAnchorHash}
                    - Enclave Lanes Locked to Active Snapshot.
                """.trimIndent()
                
                CoroutineScope(Dispatchers.Main).launch {
                    _validationEvents.emit(alert)
                }
            }
        } catch (e: Exception) {
            val errorAlert = """
                [!] COGNITIVE VALIDATION FAILED
                - Reason: ${e.message}
                - Agent logic drift suspected.
            """.trimIndent()
            CoroutineScope(Dispatchers.Main).launch {
                _validationEvents.emit(errorAlert)
            }
        }
    }

    fun stopValidationLoop() {
        validatorJob?.cancel()
        validatorJob = null
    }
}
