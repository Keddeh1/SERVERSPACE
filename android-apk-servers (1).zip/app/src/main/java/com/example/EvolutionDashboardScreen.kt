package com.example

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.DiagnosticCard
import com.example.ui.theme.AccentBlue

@Composable
fun EvolutionDashboardScreen(telemetry: BrainkTelemetryState, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Color(0xFF0D1117))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "EVOLUTION DASHBOARD",
            color = AccentBlue,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text("UPTIME (MIN)", color = Color.Gray, fontSize = 10.sp)
                SimpleLineChart(data = telemetry.uptimeHistory, color = Color(0xFF64B5F6))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("MEM (MB)", color = Color.Gray, fontSize = 10.sp)
                SimpleLineChart(data = telemetry.memoryHistory, color = Color(0xFFCE93D8))
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PLLStatusRing(
                isLocked = telemetry.pllLock,
                modifier = Modifier.size(100.dp)
            )
            
            Column(
                modifier = Modifier.weight(1f).padding(start = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "RUNTIME METRICS",
                    color = Color.LightGray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                
                DiagnosticCard(
                    title = "ACTIVE COGNITIVE STATE",
                    value = telemetry.thoughtProcess,
                    statusColor = if (telemetry.thoughtProcess.contains("IDLE")) Color(0xFF81C784) else Color(0xFFCE93D8),
                    modifier = Modifier.fillMaxWidth()
                )
                
                DiagnosticCard(
                    title = "CORE STATE",
                    value = telemetry.bootState,
                    statusColor = if (telemetry.bootState == "OFFLINE") Color(0xFFEF5350) else Color(0xFF81C784),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Text(
            text = "MEMORY LANE EVOLUTION (Occupancy %)",
            color = Color.LightGray,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )

        // Dynamic lane capacities based on growth. Assuming 1000L base, but expanding.
        val mathMax = maxOf(1000L, telemetry.laneMath)
        val ledgerMax = maxOf(1000L, telemetry.laneLedger)
        val codeMax = maxOf(1000L, telemetry.laneCode)

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            EvolutionLaneProgress(name = "MATH", value = telemetry.laneMath, max = mathMax)
            EvolutionLaneProgress(name = "LEDGER", value = telemetry.laneLedger, max = ledgerMax)
            EvolutionLaneProgress(name = "CODE", value = telemetry.laneCode, max = codeMax)
        }
        
        if (telemetry.activeSkills.isNotEmpty()) {
            Text(
                text = "EVOLVED CAPABILITIES: ${telemetry.activeSkills.joinToString(", ")}",
                color = AccentBlue,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun PLLStatusRing(isLocked: Boolean, modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "ring_pulse")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isLocked) 4000 else 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_rotation"
    )

    val color = if (isLocked) Color(0xFF81C784) else Color(0xFFEF5350)

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 8.dp.toPx()
            val radius = (size.minDimension - strokeWidth) / 2
            
            // Background ring
            drawCircle(
                color = color.copy(alpha = 0.2f),
                radius = radius,
                style = Stroke(width = strokeWidth)
            )
            
            // Rotating arc
            drawArc(
                color = color,
                startAngle = rotation,
                sweepAngle = if (isLocked) 270f else 90f,
                useCenter = false,
                topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }
        
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "PLL",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = if (isLocked) "LOCKED" else "SYNCING",
                color = color,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun EvolutionLaneProgress(name: String, value: Long, max: Long) {
    val percentage = if (max > 0) (value.toFloat() / max.toFloat()) * 100f else 0f
    
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = name,
                color = Color.White,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "${"%.1f".format(percentage)}% ($value)",
                color = Color.Gray,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0x1AFFFFFF))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction = percentage / 100f)
                    .fillMaxHeight()
                    .background(
                        color = when {
                            percentage > 100f -> Color(0xFFCE93D8) // Overdrive
                            percentage > 80f -> Color(0xFF64B5F6) // High occupancy
                            else -> AccentBlue // Normal
                        }
                    )
            )
        }
    }
}

@Composable
fun SimpleLineChart(data: List<Float>, color: Color, modifier: Modifier = Modifier.height(100.dp).fillMaxWidth()) {
    Canvas(modifier = modifier) {
        if (data.isEmpty()) return@Canvas
        val max = data.maxOrNull() ?: 1f
        val min = data.minOrNull() ?: 0f
        val range = if (max == min) 1f else max - min
        
        val path = androidx.compose.ui.graphics.Path()
        val xStep = size.width / (data.size - 1)
        
        data.forEachIndexed { index, value ->
            val x = index * xStep
            val y = size.height - ((value - min) / range * size.height)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        
        drawPath(path, color, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
    }
}
