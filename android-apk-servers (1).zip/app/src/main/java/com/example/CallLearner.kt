package com.example

import android.content.Context
import org.json.JSONObject
import java.io.File

object CallLearner {
    private var initialized = false
    private lateinit var memoryFile: File

    fun init(context: Context) {
        if (initialized) return
        memoryFile = File(context.filesDir, "learnt_calls.json")
        if (!memoryFile.exists()) {
            memoryFile.writeText("{}")
        }
        initialized = true
    }

    fun record(token: String, function: String) {
        if (!initialized) return
        val json = JSONObject(memoryFile.readText())
        json.put(token, function)
        memoryFile.writeText(json.toString())
    }

    fun getLearntFunction(token: String): String? {
        if (!initialized) return null
        val json = JSONObject(memoryFile.readText())
        return if (json.has(token)) json.getString(token) else null
    }
}
