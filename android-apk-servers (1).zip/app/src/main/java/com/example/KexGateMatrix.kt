package com.example

import android.app.ActivityManager
import android.content.Context
import android.os.StatFs
import com.example.data.AppDatabase
import com.example.data.DiagnosticReceipt
import com.example.data.ProvenanceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.UUID

enum class GateStatus {
    PASSED,
    FAILED,
    BLOCKED
}

data class GateResult(
    val gateId: String,
    val name: String,
    val status: GateStatus,
    val details: String,
    val durationNs: Long
)

data class GateMatrixReport(
    val passed: Boolean,
    val results: List<GateResult>,
    val totalDurationNs: Long,
    val failureGate: String? = null,
    val summary: String = ""
)

object KexGateMatrix {

    /**
     * Executes the sequential Fail-Closed Gate Matrix (G0 to G8).
     * Any failure at G0..G6 immediately triggers fail-closed governance (G7),
     * preventing state commitment (G8).
     */
    suspend fun evaluate(
        context: Context,
        database: AppDatabase,
        seedDecimal: Long = KexSeedAuthority.A8_SEED_DECIMAL
    ): GateMatrixReport = withContext(Dispatchers.IO) {
        val totalStartNs = System.nanoTime()
        val results = mutableListOf<GateResult>()
        var abort = false
        var failureGate: String? = null

        // -------------------------------------------------------------
        // G0: Seed & Format Integrity
        // -------------------------------------------------------------
        val g0Start = System.nanoTime()
        val seedReceipt = KexSeedAuthority.verify(seedDecimal)
        val g0Passed = seedReceipt.isValid
        val g0Duration = System.nanoTime() - g0Start

        if (g0Passed) {
            results.add(GateResult("G0", "Seed & Format Integrity", GateStatus.PASSED, "Seed 0x${"%016X".format(seedReceipt.seedDecimal)} decoded: Prefix='${seedReceipt.asciiPrefix}', Anchor='${seedReceipt.anchorChar}'", g0Duration))
        } else {
            results.add(GateResult("G0", "Seed & Format Integrity", GateStatus.FAILED, "Seed validation failed: prefix=${seedReceipt.asciiPrefix}, anchor=${seedReceipt.anchorChar}", g0Duration))
            abort = true
            failureGate = "G0"
        }

        // -------------------------------------------------------------
        // G1: Coordinate & Spatial Invariant
        // -------------------------------------------------------------
        val g1Start = System.nanoTime()
        if (abort) {
            results.add(GateResult("G1", "Coordinate & Address Invariant", GateStatus.BLOCKED, "Blocked by prior gate failure", 0L))
        } else {
            val upper = KexSeedAuthority.SPATIAL_UPPER
            val lower = KexSeedAuthority.SPATIAL_LOWER
            val g1Passed = (upper > lower) && (upper == 10.888442) && (lower == -6587044.0)
            val g1Duration = System.nanoTime() - g1Start
            if (g1Passed) {
                results.add(GateResult("G1", "Coordinate & Address Invariant", GateStatus.PASSED, "Spatial bounds locked: [$lower, $upper]. 1-origin addressing verified.", g1Duration))
            } else {
                results.add(GateResult("G1", "Coordinate & Address Invariant", GateStatus.FAILED, "Bounds mismatch: [$lower, $upper]", g1Duration))
                abort = true
                failureGate = "G1"
            }
        }

        // -------------------------------------------------------------
        // G2: Cryptographic Digest Invariant
        // -------------------------------------------------------------
        val g2Start = System.nanoTime()
        if (abort) {
            results.add(GateResult("G2", "Cryptographic Digest Invariant", GateStatus.BLOCKED, "Blocked by prior gate failure", 0L))
        } else {
            val digest = seedReceipt.sha256Digest
            val g2Passed = digest.isNotEmpty() && (digest.length == 64)
            val g2Duration = System.nanoTime() - g2Start
            if (g2Passed) {
                results.add(GateResult("G2", "Cryptographic Digest Invariant", GateStatus.PASSED, "SHA-256 Digest calculated: ${digest.take(16)}...", g2Duration))
            } else {
                results.add(GateResult("G2", "Cryptographic Digest Invariant", GateStatus.FAILED, "Digest computation failure", g2Duration))
                abort = true
                failureGate = "G2"
            }
        }

        // -------------------------------------------------------------
        // G3: Computational Invariant (VFD Strand Length)
        // -------------------------------------------------------------
        val g3Start = System.nanoTime()
        if (abort) {
            results.add(GateResult("G3", "Computational Invariant", GateStatus.BLOCKED, "Blocked by prior gate failure", 0L))
        } else {
            val strand = seedReceipt.vfdStrandLength
            val g3Passed = (strand == KexSeedAuthority.EXPECTED_STRAND_LENGTH)
            val g3Duration = System.nanoTime() - g3Start
            if (g3Passed) {
                results.add(GateResult("G3", "Computational Invariant", GateStatus.PASSED, "VFD logarithmic strand exact match: $strand digits.", g3Duration))
            } else {
                results.add(GateResult("G3", "Computational Invariant", GateStatus.FAILED, "Strand mismatch: expected ${KexSeedAuthority.EXPECTED_STRAND_LENGTH}, got $strand", g3Duration))
                abort = true
                failureGate = "G3"
            }
        }

        // -------------------------------------------------------------
        // G4: SQLite Database Invariant
        // -------------------------------------------------------------
        val g4Start = System.nanoTime()
        if (abort) {
            results.add(GateResult("G4", "Persistence & Database Invariant", GateStatus.BLOCKED, "Blocked by prior gate failure", 0L))
        } else {
            var dbOk = false
            var dbMsg = ""
            try {
                val db = database.openHelper.readableDatabase
                val cursor = db.query("PRAGMA quick_check;")
                if (cursor.moveToFirst()) {
                    val pragmaResult = cursor.getString(0)
                    dbOk = (pragmaResult.equals("ok", ignoreCase = true))
                    dbMsg = "SQLite integrity PRAGMA: $pragmaResult"
                } else {
                    dbMsg = "Cursor empty on PRAGMA check"
                }
                cursor.close()
            } catch (e: Exception) {
                dbMsg = "DB Exception: ${e.message}"
            }
            val g4Duration = System.nanoTime() - g4Start
            if (dbOk) {
                results.add(GateResult("G4", "Persistence & Database Invariant", GateStatus.PASSED, dbMsg, g4Duration))
            } else {
                results.add(GateResult("G4", "Persistence & Database Invariant", GateStatus.FAILED, dbMsg, g4Duration))
                abort = true
                failureGate = "G4"
            }
        }

        // -------------------------------------------------------------
        // G5: Host Environment & Telemetry Invariant
        // -------------------------------------------------------------
        val g5Start = System.nanoTime()
        if (abort) {
            results.add(GateResult("G5", "Host Environment Invariant", GateStatus.BLOCKED, "Blocked by prior gate failure", 0L))
        } else {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(memInfo)

            val cpuCores = Runtime.getRuntime().availableProcessors()
            val totalMemMb = if (memInfo.totalMem > 0) memInfo.totalMem / (1024 * 1024) else Runtime.getRuntime().maxMemory() / (1024 * 1024)
            val availMemMb = if (memInfo.availMem > 0) memInfo.availMem / (1024 * 1024) else Runtime.getRuntime().freeMemory() / (1024 * 1024)

            val g5Passed = (cpuCores > 0) && (totalMemMb > 0)
            val g5Duration = System.nanoTime() - g5Start
            if (g5Passed) {
                results.add(GateResult("G5", "Host Environment Invariant", GateStatus.PASSED, "Hardware verified: Cores=$cpuCores, RAM=${availMemMb}/${totalMemMb}MB", g5Duration))
            } else {
                results.add(GateResult("G5", "Host Environment Invariant", GateStatus.FAILED, "Low memory or invalid CPU: Avail=${availMemMb}MB, Cores=$cpuCores", g5Duration))
                abort = true
                failureGate = "G5"
            }
        }

        // -------------------------------------------------------------
        // G6: Storage Canary Write/Verify/Delete Invariant
        // -------------------------------------------------------------
        val g6Start = System.nanoTime()
        if (abort) {
            results.add(GateResult("G6", "Storage Canary Invariant", GateStatus.BLOCKED, "Blocked by prior gate failure", 0L))
        } else {
            var canaryPassed = false
            var canaryDetails = ""
            val canaryFile = File(context.filesDir, "canary_${UUID.randomUUID()}.bin")
            try {
                val statBytes = try { StatFs(context.filesDir.path).availableBytes } catch (e: Exception) { 0L }
                val freeBytes = if (statBytes > 0) statBytes else Runtime.getRuntime().freeMemory()
                
                val testBytes = ByteArray(64) { (it * 7).toByte() }
                canaryFile.writeBytes(testBytes)

                val readBack = canaryFile.readBytes()
                val md = MessageDigest.getInstance("SHA-256")
                val hashWritten = md.digest(testBytes).joinToString("") { "%02x".format(it) }
                md.reset()
                val hashRead = md.digest(readBack).joinToString("") { "%02x".format(it) }

                canaryPassed = (hashWritten == hashRead) && (readBack.contentEquals(testBytes)) && (freeBytes > 0)
                canaryDetails = "Canary write-readback hash match: ${hashWritten.take(12)}... (Free: ${freeBytes / (1024 * 1024)}MB)"
            } catch (e: Exception) {
                canaryDetails = "Canary failed: ${e.message}"
            } finally {
                if (canaryFile.exists()) {
                    canaryFile.delete()
                }
            }
            val g6Duration = System.nanoTime() - g6Start
            if (canaryPassed) {
                results.add(GateResult("G6", "Storage Canary Invariant", GateStatus.PASSED, canaryDetails, g6Duration))
            } else {
                results.add(GateResult("G6", "Storage Canary Invariant", GateStatus.FAILED, canaryDetails, g6Duration))
                abort = true
                failureGate = "G6"
            }
        }

        // -------------------------------------------------------------
        // G7: Fail-Closed Governance Invariant
        // -------------------------------------------------------------
        val g7Start = System.nanoTime()
        val g7Passed = !abort
        val g7Duration = System.nanoTime() - g7Start
        if (g7Passed) {
            results.add(GateResult("G7", "Fail-Closed Governance", GateStatus.PASSED, "All precursor gates (G0..G6) passed. Execution clear for commitment.", g7Duration))
        } else {
            results.add(GateResult("G7", "Fail-Closed Governance", GateStatus.FAILED, "Fail-Closed triggered at gate $failureGate. Aborting state commitment.", g7Duration))
        }

        // -------------------------------------------------------------
        // G8: State Commitment & Empirical Receipt Invariant
        // -------------------------------------------------------------
        val g8Start = System.nanoTime()
        if (!g7Passed) {
            results.add(GateResult("G8", "State Commitment Invariant", GateStatus.BLOCKED, "Commitment rejected: Fail-closed governance blocked transition", 0L))
        } else {
            var commitPassed = false
            var commitDetails = ""
            try {
                val receiptPayload = JSONObject().apply {
                    put("gate_evaluation_id", UUID.randomUUID().toString())
                    put("seed_digest", seedReceipt.sha256Digest)
                    put("vfd_strand", seedReceipt.vfdStrandLength)
                    put("timestamp_ns", System.nanoTime())
                    put("verdict", "EMPIRICALLY_VERIFIED")
                }

                val receipt = DiagnosticReceipt(
                    taskId = "GATE_EVALUATION_${System.currentTimeMillis()}",
                    resultData = receiptPayload.toString(),
                    provenanceId = ProvenanceType.EMPIRICALLY_VERIFIED
                )
                database.diagnosticReceiptDao().insertReceipt(receipt)
                commitPassed = true
                commitDetails = "State snapshot committed to Room with EMPIRICALLY_VERIFIED receipt (Task ID: ${receipt.taskId})"
            } catch (e: Exception) {
                commitDetails = "Commitment failed: ${e.message}"
            }
            val g8Duration = System.nanoTime() - g8Start
            if (commitPassed) {
                results.add(GateResult("G8", "State Commitment Invariant", GateStatus.PASSED, commitDetails, g8Duration))
            } else {
                results.add(GateResult("G8", "State Commitment Invariant", GateStatus.FAILED, commitDetails, g8Duration))
            }
        }

        val totalDuration = System.nanoTime() - totalStartNs
        val allPassed = results.all { it.status == GateStatus.PASSED }
        
        GateMatrixReport(
            passed = allPassed,
            results = results,
            totalDurationNs = totalDuration,
            failureGate = failureGate,
            summary = if (allPassed) "ALL GATES (G0..G8) EMPIRICALLY VERIFIED" else "EXECUTION HALTED AT $failureGate (FAIL-CLOSED)"
        )
    }
}
