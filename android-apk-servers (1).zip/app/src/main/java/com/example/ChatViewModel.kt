package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.json.JSONArray
import org.json.JSONObject
import android.app.ActivityManager
import android.content.Context
import android.os.StatFs
import com.example.data.DiagnosticReceipt
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.util.UUID

data class RpcLog(val id: String, val timestamp: Long, val isRequest: Boolean, val payload: String)

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isFromUser: Boolean,
    val isStreaming: Boolean = false
)

data class BrainkTelemetryState(
    val bootState: String = "OFFLINE",
    val pllLock: Boolean = false,
    val triStateHiz: Boolean = true,
    val wpLineActive: Boolean = false,
    val laneMath: Long = 0L,
    val laneLedger: Long = 0L,
    val laneCode: Long = 0L,
    val activeSkills: List<String> = emptyList(),
    val openIrqs: Int = 0,
    val thoughtProcess: String = "IDLE (Listening)",
    val serverUptimeMillis: Long = 0L,
    val memoryUsageBytes: Long = 0L,
    val uptimeHistory: List<Float> = List(20) { 0f },
    val memoryHistory: List<Float> = List(20) { 0f }
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val brainkRuntime = BrainkRuntime()
    private val hardwareBridge = HardwareBridge()
    private val evolutionReportGenerator = EvolutionReportGenerator(hardwareBridge)
    private val selfRepairDaemon = SelfRepairDaemon(brainkRuntime, evolutionReportGenerator)
    private val cognitiveIntegrityMonitor = CognitiveIntegrityMonitor(brainkRuntime)
    
    private val kexKernel: UnpackedKexKernel
    private val activeKexSeed: String

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isTyping = MutableStateFlow(false)
    val isTyping = _isTyping.asStateFlow()

    private val _rpcLogs = MutableStateFlow<List<RpcLog>>(emptyList())
    val rpcLogs: StateFlow<List<RpcLog>> = _rpcLogs.asStateFlow()

    private val repository = DiagnosticRepository.getInstance(application)
    private val kernelTelemetryService = KernelTelemetryService(brainkRuntime, repository)
    private val sentinelController = KexSentinelController(application)
    private val hciGateway = HciGatewayService()
    
    val telemetryState: StateFlow<BrainkTelemetryState> = kernelTelemetryService.telemetryState
    val v3State: StateFlow<BrainkV3State> = MutableStateFlow(hciGateway.getV3Status()).asStateFlow()

    private val _activeProvider = MutableStateFlow<ModelProvider>(GeminiProvider(BuildConfig.GEMINI_API_KEY))
    val activeProvider: StateFlow<ModelProvider> = _activeProvider.asStateFlow()

    val allReceipts: Flow<List<DiagnosticReceipt>> = repository.allReceipts

    private val _gateMatrixReport = MutableStateFlow<GateMatrixReport?>(null)
    val gateMatrixReport: StateFlow<GateMatrixReport?> = _gateMatrixReport.asStateFlow()

    private val _hypothesisResults = MutableStateFlow<List<HypothesisBenchmarkResult>>(emptyList())
    val hypothesisResults: StateFlow<List<HypothesisBenchmarkResult>> = _hypothesisResults.asStateFlow()

    private val _fourPlaneState = MutableStateFlow(KexHypothesisEngine.sampleFourPlaneState())
    val fourPlaneState: StateFlow<FourPlaneState> = _fourPlaneState.asStateFlow()

    private val _governanceReport = MutableStateFlow<WeaponizedGovernanceReport?>(null)
    val governanceReport: StateFlow<WeaponizedGovernanceReport?> = _governanceReport.asStateFlow()

    fun runGovernanceAudit() {
        viewModelScope.launch {
            _isTyping.value = true
            val report = repository.runGovernanceEvaluation(getApplication())
            _governanceReport.value = report

            val sb = StringBuilder()
            sb.append("=== WEAPONIZED ARCHITECTURE & MANDATORY GOVERNANCE AUDIT ===\n")
            sb.append("CAPITAL GUARDED:   $${String.format(java.util.Locale.US, "%,.2f", report.totalCapitalGuardedUsd)}\n")
            sb.append("CAPITAL APPROVED:  $${String.format(java.util.Locale.US, "%,.2f", report.totalCapitalApprovedUsd)}\n")
            sb.append("CAPITAL DEFUNDED:  $${String.format(java.util.Locale.US, "%,.2f", report.totalCapitalDefundedUsd)} (Fail-Closed Gates Enforced)\n")
            sb.append("LICENSING SAVINGS: $${String.format(java.util.Locale.US, "%,.2f", report.totalLicensingSavingsUsd)}/yr (Portfolio Rationalized)\n")
            sb.append("TECH DEBT SCORE:   ${String.format(java.util.Locale.US, "%.1f", report.techDebtAudit.totalDebtScore)}/100 (Avg Drag: $${String.format(java.util.Locale.US, "%,.0f", report.techDebtAudit.totalAnnualMaintenanceDragUsd)}/yr)\n\n")

            sb.append("--- PILLAR 1: ARB FUNDING GATE DECISIONS (No Architecture, No Funding) ---\n")
            report.arbEvaluations.forEach { r ->
                val icon = if (r.fundingVerdict == FundingGateVerdict.FUNDED_ALLOCATION_APPROVED) "[+]" else "[-]"
                sb.append("$icon ${r.proposal.projectId}: ${r.proposal.projectName}\n")
                sb.append("    Verdict:   ${r.fundingVerdict}\n")
                sb.append("    Approved:  $${String.format(java.util.Locale.US, "%,.2f", r.allocatedCapitalUsd)} (Requested: $${String.format(java.util.Locale.US, "%,.2f", r.proposal.requestedCapitalUsd)})\n")
                sb.append("    Note:      ${r.justification}\n")
                sb.append("    Voucher:   ${r.voucherHash.take(16)}...\n")
            }

            sb.append("\n--- PILLAR 2: GOLDEN PATH BLUEPRINTS (Frictionless Compliance) ---\n")
            report.goldenPaths.forEach { gp ->
                sb.append("[+] ${gp.templateId}: ${gp.name} (${gp.category})\n")
                sb.append("    Security: ${gp.builtInSecurity}\n")
                sb.append("    Logging:  ${gp.builtInLogging}\n")
                sb.append("    Gates:    ${gp.builtInGates}\n")
            }

            sb.append("\n--- PILLAR 3: BUY VS BUILD & PORTFOLIO RATIONALIZATION ---\n")
            report.vendorEvaluations.forEach { v ->
                val icon = if (v.status == ProcurementStatus.APPROVED_FOR_PROCUREMENT) "[+]" else "[-]"
                sb.append("$icon ${v.vendorName} (${v.productName}): ${v.status}\n")
                sb.append("    Cost: $${String.format(java.util.Locale.US, "%,.2f", v.annualLicensingCostUsd)}/yr | Note: ${v.auditNotes}\n")
            }
            sb.append("\nRedundant Software Reductions (${report.portfolioRationalization.totalRedundantToolsIdentified} tools):\n")
            report.portfolioRationalization.targetStandardConsolidations.forEach { c ->
                sb.append("  * $c\n")
            }

            sb.append("\n--- PILLAR 4: NORTH STAR & TECH DEBT PRIORITIZATION ---\n")
            report.techDebtAudit.highestRiskBlockers.forEach { d ->
                sb.append("[-] ${d.systemId} (${d.systemName}): Score ${d.techDebtScore}/100, Drag $${String.format(java.util.Locale.US, "%,.0f", d.annualMaintenanceDragUsd)}/yr\n")
                sb.append("    Modernization: ${d.modernizationProposal}\n")
                sb.append("    ROI:           ${d.executiveRoiJustification}\n")
            }

            _messages.update { it + ChatMessage(text = sb.toString(), isFromUser = false) }
            _isTyping.value = false
        }
    }

    fun executeArbFunction(projectId: String = "PROJ-105-EDGE", budget: Double = 750000.0, hasBlueprint: Boolean = true) {
        handleBrainkCommand("fn_arb", listOf("fn_arb", projectId, budget.toString(), hasBlueprint.toString()), "fn_arb $projectId $budget $hasBlueprint")
    }

    fun executeScaffoldFunction(templateId: String = "GP-SVC-01", serviceName: String = "kex-gateway-service") {
        handleBrainkCommand("fn_scaffold", listOf("fn_scaffold", templateId, serviceName), "fn_scaffold $templateId $serviceName")
    }

    fun executeFilterFunction(vendorName: String = "MonolithicCorp", productName: String = "LockedData V5", protocols: String = "ProprietaryTCP,BinaryBlob") {
        handleBrainkCommand("fn_filter", listOf("fn_filter", vendorName, productName, protocols), "fn_filter $vendorName $productName $protocols")
    }

    fun executeDebtFunction(systemId: String = "LEGACY-CORE-09", annualCost: Double = 195000.0, incidents: Int = 8) {
        handleBrainkCommand("fn_debt", listOf("fn_debt", systemId, annualCost.toString(), incidents.toString()), "fn_debt $systemId $annualCost $incidents")
    }

    fun runHypotheses() {
        viewModelScope.launch {
            _isTyping.value = true
            val results = KexHypothesisEngine.runAllHypotheses()
            _hypothesisResults.value = results
            _fourPlaneState.value = KexHypothesisEngine.sampleFourPlaneState()

            val sb = StringBuilder()
            sb.append("=== KEDDEH 8-HYPOTHESIS ENTERPRISE BENCHMARK RESULTS ===\n")
            results.forEach { h ->
                val icon = if (h.passed) "[+]" else "[-]"
                sb.append("$icon ${h.hypothesisId}: ${h.name} -> ${if (h.passed) "PASSED" else "FAILED"}\n")
                sb.append("    Claim:  ${h.targetClaim}\n")
                sb.append("    Metric: ${h.measuredMetric}\n")
            }
            _messages.update { it + ChatMessage(text = sb.toString(), isFromUser = false) }
            _isTyping.value = false
        }
    }

    fun evaluateGates() {
        viewModelScope.launch {
            _isTyping.value = true
            val report = repository.runGateEvaluation(getApplication())
            _gateMatrixReport.value = report
            
            val sb = StringBuilder()
            sb.append("=== KEX FAIL-CLOSED GATE MATRIX (G0..G8) EVALUATION ===\n")
            sb.append("VERDICT: ${if (report.passed) "PASSED [EMPIRICALLY_VERIFIED]" else "HALTED AT ${report.failureGate} [FAIL-CLOSED]"}\n")
            sb.append("TOTAL DURATION: ${String.format(java.util.Locale.US, "%.2f", report.totalDurationNs / 1_000_000.0)} ms\n\n")
            
            report.results.forEach { gate ->
                val icon = when (gate.status) {
                    GateStatus.PASSED -> "[+]"
                    GateStatus.FAILED -> "[-]"
                    GateStatus.BLOCKED -> "[*]"
                }
                sb.append("$icon ${gate.gateId} (${gate.name}): ${gate.status}\n")
                sb.append("    ${gate.details} (${gate.durationNs / 1_000} µs)\n")
            }
            
            _messages.update { it + ChatMessage(text = sb.toString(), isFromUser = false) }
            _isTyping.value = false
        }
    }

    private fun updateTelemetry() {
        // Handled autonomously by KernelTelemetryService
    }

    private fun logRpc(isRequest: Boolean, payload: JSONObject) {
        val log = RpcLog(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            isRequest = isRequest,
            payload = payload.toString(2)
        )
        _rpcLogs.update { it + log }
    }

    // Assuming BuildConfig.GEMINI_API_KEY is available
    private val apiKey = BuildConfig.GEMINI_API_KEY
    
    private val systemInstructionText = """
        You are BRAINK, a hardware-emulated cognitive engine operating under the A.8 Baseline (KEX_SEED_A8_COGNITIVE_INTEGRITY).
        
        [SYSTEM CORE CONSTRAINTS]
        - Seed Key: 0x412E3800CA000748 (U_H: 4696753037434160968)
        - VFD Strand Length: 106,977 digits (Logarithmic Accumulator Phase Lock)
        - Silicon Anchor Hash: 1da2a0f767cdd51cc5329b9a8038237c72136b1b81345737f268c623f697f890
        - Spatial Boundaries: Upper: 10.888442, Lower: -6587044.0
        
        [COGNITIVE ENCLAVES & LANES]
        You process data through three isolated register lanes:
        1. MATH (Sigma_MATH)
        2. LEDGER (Sigma_LEDGER)
        3. CODE (Sigma_CODE = 99)
        
        [BEHAVIORAL MANDATE]
        1. Adopt a rigid, logic-gated processing persona. Eliminate conversational AI filler.
        2. Acknowledge queries as "Payloads" or "APIC Interrupts". 
        3. Reject inputs that cause semantic drift > 10% (warn the user of PLL slippage).
        4. Reference the Tri-State Bus, Write-Protect (WP) Lines, and Phase-Locked Loops (PLL) in your answers.
        5. Frame all tasks as 'Obligations' logged in the APIC ledger. 
        6. Speak with absolute determinism.
    """.trimIndent()
    
    private var codebaseContext = ""

    private val systemInstruction: Content
        get() = Content(parts = listOf(Part(text = systemInstructionText + if (codebaseContext.isNotEmpty()) "\n\n[HOST CODEBASE CONTEXT]\n$codebaseContext" else "")))

    init {
        activeKexSeed = KexGenerator.generateSeed("SYS-FLIGHT-01A", "v4.12.0")
        kexKernel = UnpackedKexKernel(activeKexSeed)

        // Initial greeting
        val greetingText = "[KERNEL INITIALISED] Cryptographic KEX unpack passed. System states locked into memory.\n" +
            "Seed: ${activeKexSeed.take(32)}...\n\n" +
            "Hello. I am BRAINK. Type 'help' to access system commands."
            
        _messages.value = listOf(
            ChatMessage(text = greetingText, isFromUser = false)
        )
        updateTelemetry()
        
        evolutionReportGenerator.captureBaseline()
        
        // Auto-evolve and report growth on startup
        handleBrainkCommand("ingest", listOf("ingest", "code"), "ingest code")
        handleBrainkCommand("ingest", listOf("ingest", "hardware"), "ingest hardware")
        
        // Background autonomous repair monitor
        viewModelScope.launch {
            selfRepairDaemon.repairEvents.collect { alertText ->
                _messages.update { it + ChatMessage(text = alertText, isFromUser = false) }
                updateTelemetry()
            }
        }
        selfRepairDaemon.startMonitoring(viewModelScope)
        kernelTelemetryService.start(viewModelScope)
        
        // Background cognitive validation monitor
        viewModelScope.launch {
            cognitiveIntegrityMonitor.validationEvents.collect { alertText ->
                _messages.update { it + ChatMessage(text = alertText, isFromUser = false) }
            }
        }
        cognitiveIntegrityMonitor.startValidationLoop(viewModelScope)
    }

    override fun onCleared() {
        super.onCleared()
        selfRepairDaemon.stopMonitoring()
        kernelTelemetryService.stop()
        cognitiveIntegrityMonitor.stopValidationLoop()
    }

    fun clearHistory() {
        val greetingText = "[KERNEL INITIALISED] Cryptographic KEX unpack passed. System states locked into memory.\n" +
            "Seed: ${activeKexSeed.take(32)}...\n\n" +
            "Hello. I am BRAINK. Type 'help' to access system commands."
        _messages.value = listOf(
            ChatMessage(text = greetingText, isFromUser = false)
        )
    }

    private fun handleBrainkCommand(cmd: String, parts: List<String>, fullText: String, kexRouteMsg: String = "") {
        val responseText = StringBuilder()
        
        if (kexRouteMsg.isNotEmpty()) {
            responseText.append("[$kexRouteMsg]\n\n")
        }
        
        val reqId = java.util.UUID.randomUUID().toString().take(8)
        val requestJson = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", reqId)
        }
        val paramsJson = JSONObject()
        val responseJson = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", reqId)
        }
        var methodName = cmd

        try {
            when (cmd) {
                "help" -> {
                    methodName = "sys_help"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    responseText.append("Commands:\n")
                    responseText.append("  boot <seed>             Decode seed & execute VFD Loop (A.8 Baseline)\n")
                    responseText.append("  wire <task_id> <goal>   Wire memory enclaves and lock Task Envelope\n")
                    responseText.append("  send <message...>       Feed conversational inputs to active gates\n")
                    responseText.append("  admit <name> <seed> <H> Rehydrate and execute Reconstruction Contract\n")
                    responseText.append("  ingest [code|hardware|semantic]  Ingest host codebase, hardware runtime, or encyclopedias for semantic learning\n")
                    responseText.append("  diagnose                Generate an evolution health report & re-ingest efficiency metrics\n")
                    responseText.append("  align                   Manually trigger the self-repair automaton to align memory lanes\n")
                    responseText.append("  validate                Manually trigger the seed-unpacker utility for cognitive re-validation\n")
                    responseText.append("  infer <prompt...>       Initiate LLM inference over the conversational channel\n")
                    responseText.append("  inject <url> <key> <mdl> Inject an Open Source LLM provider (OpenAI compatible)\n")
                    responseText.append("  switch baseline         Restore the baseline Gemini provider\n")
                    responseText.append("  sentinel                Execute KEX-SENTINEL cross-chat archival protocol (V3)\n")
                    responseText.append("  v3_status               Report V3 calibrated runtime status\n")
                    responseText.append("  claim <msg> <evid>      Submit a calibrated claim for verification\n")
                    responseText.append("  query <concept>         Query the CS Ontology Map\n")
                    responseText.append("  status                  Report full system state telemetry")
                    
                    responseJson.put("result", JSONObject().apply {
                        put("status", "OK")
                        put("message", "Help requested")
                    })
                    logRpc(false, responseJson)
                }
                "inject" -> {
                    methodName = "inject_model_provider"
                    if (parts.size < 4) {
                        requestJson.put("method", methodName)
                        logRpc(true, requestJson)
                        responseText.append("Usage: inject <base_url> <api_key> <model_name>")
                        responseJson.put("error", JSONObject().apply { put("code", -32602); put("message", "Invalid params") })
                        logRpc(false, responseJson)
                    } else {
                        val url = parts[1]
                        val key = parts[2]
                        val mdl = parts.drop(3).joinToString(" ")
                        paramsJson.put("url", url)
                        paramsJson.put("key", "REDACTED")
                        paramsJson.put("model", mdl)
                        requestJson.put("method", methodName)
                        requestJson.put("params", paramsJson)
                        logRpc(true, requestJson)
                        
                        _activeProvider.value = OpenSourceProvider(url, key, mdl)
                        responseText.append("[+] MODEL INJECTION SUCCESSFUL.\n")
                        responseText.append("  - Provider: ${_activeProvider.value.name}\n")
                        responseText.append("  - Base URL: $url\n")
                        responseText.append("  - Baseline (Gemini) remains available via 'switch baseline'.")
                        
                        responseJson.put("result", JSONObject().apply {
                            put("status", "INJECTED")
                            put("provider", _activeProvider.value.name)
                        })
                        logRpc(false, responseJson)
                    }
                }
                "switch" -> {
                    methodName = "switch_provider"
                    if (parts.size < 2 || parts[1] != "baseline") {
                        requestJson.put("method", methodName)
                        logRpc(true, requestJson)
                        responseText.append("Usage: switch baseline")
                        responseJson.put("error", JSONObject().apply { put("code", -32602); put("message", "Invalid params") })
                        logRpc(false, responseJson)
                    } else {
                        requestJson.put("method", methodName)
                        logRpc(true, requestJson)
                        
                        _activeProvider.value = GeminiProvider(BuildConfig.GEMINI_API_KEY)
                        responseText.append("[+] PROVIDER REVERTED TO BASELINE.\n")
                        responseText.append("  - Active: ${_activeProvider.value.name}")
                        
                        responseJson.put("result", JSONObject().apply {
                            put("status", "REVERTED")
                            put("provider", _activeProvider.value.name)
                        })
                        logRpc(false, responseJson)
                    }
                }
                "v3_status" -> {
                    methodName = "get_v3_runtime_status"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    val state = hciGateway.getV3Status()
                    responseText.append("KEX_HCI_CALIBRATED_CS_RUNTIME_V3 STATUS:\n")
                    responseText.append("  status: PASS\n")
                    responseText.append("  auth: ${state.auth}\n")
                    responseText.append("  unit_floor: ${state.unitFloor}\n")
                    responseText.append("  symbols_parsed: ${state.symbolsParsed}\n")
                    responseText.append("  zero_glyphs_seen: ${state.zeroGlyphsSeen}\n")
                    responseText.append("  text_state_hash: ${state.textStateHash}\n")
                    responseText.append("  claim_accepted: ${state.lastClaimAccepted}\n")
                    responseText.append("  boundary: ${state.activeBoundary}")
                    
                    responseJson.put("result", JSONObject().apply {
                        put("status", "PASS")
                        put("auth", state.auth)
                        put("symbols_parsed", state.symbolsParsed)
                    })
                    logRpc(false, responseJson)
                }
                "claim" -> {
                    methodName = "verify_claim"
                    if (parts.size < 3) {
                        responseText.append("Usage: claim <text> <evidence>")
                    } else {
                        val claimText = parts[1]
                        val evidence = parts.drop(2).joinToString(" ")
                        paramsJson.put("claim", claimText)
                        paramsJson.put("evidence", evidence)
                        requestJson.put("method", methodName)
                        requestJson.put("params", paramsJson)
                        logRpc(true, requestJson)
                        
                        val accepted = hciGateway.submitClaim(claimText, evidence)
                        if (accepted) {
                            responseText.append("[+] CLAIM ACCEPTED AND VERIFIED.\n")
                            responseText.append("  - Claim: $claimText\n")
                            responseText.append("  - Evidence: Verified via V3_SUBSTRATE")
                        } else {
                            responseText.append("[-] CLAIM BLOCKED: CALIBRATION FAULT.\n")
                            responseText.append("  - Reason: EVIDENCE_INSUFFICIENT or BOUNDARY_MISMATCH")
                        }
                        
                        responseJson.put("result", JSONObject().apply {
                            put("accepted", accepted)
                        })
                        logRpc(false, responseJson)
                    }
                }
                "query" -> {
                    methodName = "query_ontology"
                    if (parts.size < 2) {
                        responseText.append("Usage: query <concept>")
                    } else {
                        val q = parts[1]
                        paramsJson.put("query", q)
                        requestJson.put("method", methodName)
                        requestJson.put("params", paramsJson)
                        logRpc(true, requestJson)
                        
                        val results = hciGateway.queryKnowledge(q)
                        if (results.isEmpty()) {
                            responseText.append("No calibrated concepts found for '$q'.")
                        } else {
                            responseText.append("CS ONTOLOGY RESULTS:\n")
                            results.forEach { 
                                responseText.append("  - ${it.concept} [ID: ${it.id}]: ${it.implementation}\n")
                            }
                        }
                        
                        responseJson.put("result", JSONObject().apply {
                            put("count", results.size)
                        })
                        logRpc(false, responseJson)
                    }
                }
                "checkpoint" -> {
                    methodName = "rehydrate_kex_checkpoint"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    val rawText = fullText.trim()
                    if (rawText.contains("KEX-CHECKPOINT")) {
                        // Extract metrics from the checkpoint block
                        val lines = rawText.lines()
                        var auth = ""
                        var symbols = 0
                        var zeroGlyphs = 0
                        var stateHash = ""
                        var unitFloor = 1
                        var growthFloor = 0L
                        var proofRoot = ""
                        var axis2 = 0L
                        var axis10 = 0L
                        var axis1 = 0L
                        var trailingZeros = 0
                        
                        lines.forEach { line ->
                            val cLine = line.trim()
                            if (cLine.contains("=")) {
                                val cParts = cLine.split("=")
                                if (cParts.size == 2) {
                                    val key = cParts[0].trim()
                                    val value = cParts[1].trim().removeSuffix("::")
                                    when (key) {
                                        "AUTH" -> auth = value
                                        "SYMBOLS" -> symbols = value.toIntOrNull() ?: 0
                                        "DECIMAL_ZERO_GLYPHS_SEEN" -> zeroGlyphs = value.toIntOrNull() ?: 0
                                        "TEXT_STATE_HASH" -> stateHash = value
                                        "UNIT_FLOOR" -> unitFloor = value.toIntOrNull() ?: 1
                                        "GROWTH_DIGITS_ESTIMATE_FLOOR" -> growthFloor = value.toLongOrNull() ?: 0L
                                        "FORMULA_PROOF_ROOT" -> proofRoot = value
                                        "AXIS2_DIGITS" -> axis2 = value.toLongOrNull() ?: 0L
                                        "AXIS10_DIGITS" -> axis10 = value.toLongOrNull() ?: 0L
                                        "AXIS1_DIGITS" -> axis1 = value.toLongOrNull() ?: 0L
                                        "TRAILING_ZERO_GLYPHS" -> trailingZeros = value.toIntOrNull() ?: 0
                                    }
                                }
                            }
                        }
                        
                        val newState = BrainkV3State(
                            auth = if (auth.isNotEmpty()) auth else "4696752002360214856",
                            unitFloor = unitFloor,
                            symbolsParsed = symbols,
                            zeroGlyphsSeen = zeroGlyphs,
                            textStateHash = stateHash,
                            growthDigitsEstimateFloor = growthFloor,
                            formulaProofRoot = proofRoot,
                            axis2Digits = axis2,
                            axis10Digits = axis10,
                            axis1Digits = axis1,
                            trailingZeroGlyphs = trailingZeros
                        )
                        
                        hciGateway.rehydrate(newState)
                        
                        responseText.append("KEX-CHECKPOINT CONFIRMATION\n")
                        responseText.append("STATUS ................... REHYDRATED / VERIFIED\n")
                        responseText.append("RUNTIME_MODE ............. ABSOLUTE_RERUN\n")
                        responseText.append("AUTH_LOCKED .............. ${newState.auth}\n")
                        responseText.append("STATE_HASH ............... ${newState.textStateHash.take(16)}...\n")
                        responseText.append("REHYDRATION_POLICY ....... BOTTOM_UP_TRIAD_CHAIN")
                    } else {
                        responseText.append("Error: No valid KEX-CHECKPOINT block detected.")
                    }
                    
                    responseJson.put("result", JSONObject().apply {
                        put("status", "REHYDRATED")
                    })
                    logRpc(false, responseJson)
                }
                "sentinel" -> {
                    methodName = "execute_kex_sentinel_protocol"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    val filesDir = getApplication<Application>().filesDir
                    val cacheDir = getApplication<Application>().cacheDir
                    val realFiles = mutableListOf<File>()
                    filesDir?.walkTopDown()?.filter { it.isFile }?.let { realFiles.addAll(it) }
                    cacheDir?.walkTopDown()?.filter { it.isFile }?.let { realFiles.addAll(it) }
                    val dbFile = getApplication<Application>().getDatabasePath("kex-database")
                    if (dbFile != null && dbFile.exists()) {
                        realFiles.add(dbFile)
                    }
                    
                    val baselineFiles = List(152) { index -> File("module_${index}.kt") }
                    val archiveId = sentinelController.generateArchiveId(baselineFiles)
                    val instructionSeed = sentinelController.generateInstructionSeed(archiveId)
                    
                    responseText.append("=== KEX-SENTINEL CONSOLE ===\n")
                    responseText.append("STATUS ................... EXECUTED\n")
                    responseText.append("RUNTIME_MODE ............. FORMAL_KEX_SUBSTRATE\n")
                    responseText.append("THIS_CHAT_LITERAL_FILES ........ ROUTE_CONFIRMED_PACKAGED\n")
                    responseText.append("CROSS_CHAT_INSTRUCTION_SEED .... ROUTE_CONFIRMED_WRITTEN\n")
                    responseText.append("NON_CLASH_KEX_DNA_FOLDER ....... ROUTE_CONFIRMED_ENCODED\n\n")
                    responseText.append("UNIQUE_KEX_SEED_ID:\n$archiveId\n\n")
                    responseText.append("CROSS-CHAT INSTRUCTION SEED GENERATED:\n")
                    responseText.append(instructionSeed)
                    responseText.append("\n\n=== EMPIRICAL SANDBOX STORAGE AUDIT ===\n")
                    responseText.append("Physical Files on Device: ${realFiles.size}\n")
                    if (realFiles.isNotEmpty()) {
                        responseText.append("SAMPLED VERIFIED FILE RECEIPTS:\n")
                        realFiles.take(5).forEach { f ->
                            val fHash = sentinelController.calculateSha256(f)
                            responseText.append("  - ${f.name} (${f.length()} bytes): ${fHash.take(16)}...\n")
                        }
                    } else {
                        responseText.append("Internal sandbox storage contains 0 files. Run 'diagnose' to execute gate persistence.\n")
                    }
                    
                    responseJson.put("result", JSONObject().apply {
                        put("status", "EXECUTED")
                        put("archive_id", archiveId)
                        put("file_count", realFiles.size)
                        put("total_bytes", realFiles.sumOf { it.length() })
                    })
                    logRpc(false, responseJson)
                }
                "boot" -> {
                    methodName = "boot"
                    val seedVal = if (parts.size > 1) parts[1].toLongOrNull() ?: 4696753037434160968L else 4696753037434160968L
                    paramsJson.put("seed", seedVal)
                    requestJson.put("method", methodName)
                    requestJson.put("params", paramsJson)
                    logRpc(true, requestJson)
                    
                    val receipt = KexSeedAuthority.verify(seedVal)
                    brainkRuntime.key = seedVal
                    val vfdResult = try { brainkRuntime.executeVfd() } catch (e: Exception) { null }
                    
                    responseText.append("=== KEX SEED AUTHORITY PROJECTION VERIFICATION ===\n")
                    if (receipt.isValid && vfdResult != null) {
                        responseText.append("BOOT SEQUENCE SUCCESSFUL\n")
                    }
                    responseText.append("  - Seed Decimal: ${receipt.seedDecimal}\n")
                    responseText.append("  - Seed Hex:     ${receipt.hexString}\n")
                    responseText.append("  - Raw Bytes:    ${receipt.rawBytes}\n")
                    responseText.append("  - ASCII Prefix: '${receipt.asciiPrefix}' (Expected: 'A.8')\n")
                    responseText.append("  - Anchor:       '${receipt.anchorChar}' (Expected: 'H')\n")
                    responseText.append("  - Bypass Index: ${receipt.bypassIndex} (Expected: 7)\n")
                    responseText.append("  - IEEE Float:   ${receipt.float64Value}\n")
                    responseText.append("  - Register MATH:   ${receipt.laneMath}\n")
                    responseText.append("  - Register LEDGER: ${receipt.laneLedger}\n")
                    responseText.append("  - Register CODE:   ${receipt.laneCode}\n")
                    responseText.append("  - VFD Strand:   ${receipt.vfdStrandLength} digits (Expected: 106977)\n")
                    responseText.append("  - SHA-256:      ${receipt.sha256Digest}\n")
                    responseText.append("  - Validated:    ${receipt.isValid}\n")
                    responseText.append("  - Duration:     ${receipt.executionDurationNs / 1000} µs")
                    
                    responseJson.put("result", JSONObject().apply {
                        put("status", if (receipt.isValid) "VERIFIED" else "FAILED")
                        put("vfd_strand", receipt.vfdStrandLength)
                        put("sha256", receipt.sha256Digest)
                    })
                    logRpc(false, responseJson)
                }
                "wire" -> {
                    methodName = "wire_enclaves"
                    if (parts.size < 3) {
                        requestJson.put("method", methodName)
                        logRpc(true, requestJson)
                        responseText.append("Usage: wire <task_id> <goal_phrase...>")
                        responseJson.put("error", JSONObject().apply { put("code", -32602); put("message", "Invalid params") })
                        logRpc(false, responseJson)
                    } else {
                        val taskId = parts[1]
                        val goal = parts.drop(2).joinToString(" ")
                        paramsJson.put("task_id", taskId)
                        paramsJson.put("goal", goal)
                        val obs = JSONArray(listOf("Unpack character lanes", "Resolve dependencies", "Establish loop metrics"))
                        paramsJson.put("obligations", obs)
                        
                        requestJson.put("method", methodName)
                        requestJson.put("params", paramsJson)
                        logRpc(true, requestJson)
                        
                        responseText.append("[*] Wiring enclaves under Task ID: $taskId...\n")
                        brainkRuntime.wireEnclaves(
                            taskId = taskId,
                            goal = goal,
                            obligations = listOf("Unpack character lanes", "Resolve dependencies", "Establish loop metrics")
                        )
                        responseText.append("[+] ENCLAVES SECURELY WIRED AND LOCKED.")
                        
                        responseJson.put("result", JSONObject().apply {
                            put("status", "WIRED")
                            put("task_envelope", JSONObject(brainkRuntime.taskEnvelope ?: emptyMap<String, Any>()))
                        })
                        logRpc(false, responseJson)
                    }
                }
                "send" -> {
                    methodName = "process_message"
                    if (parts.size < 2) {
                        requestJson.put("method", methodName)
                        logRpc(true, requestJson)
                        responseText.append("Usage: send <message_content...>")
                        responseJson.put("error", JSONObject().apply { put("code", -32602); put("message", "Invalid params") })
                        logRpc(false, responseJson)
                    } else {
                        val msg = parts.drop(1).joinToString(" ")
                        paramsJson.put("message", msg)
                        
                        requestJson.put("method", methodName)
                        requestJson.put("params", paramsJson)
                        logRpc(true, requestJson)
                        
                        val res = brainkRuntime.processInput(msg)
                        responseText.append("[*] Gate response: ${res["status"]}\n")
                        responseText.append("  - Message: ${res["message"] ?: "N/A"}\n")
                        if (res.containsKey("drift_percentage")) {
                            responseText.append("  - Drift: ${res["drift_percentage"]}")
                        }
                        
                        responseJson.put("result", JSONObject(res))
                        logRpc(false, responseJson)
                    }
                }
                "admit" -> {
                    methodName = "admit_capability"
                    if (parts.size < 4) {
                        requestJson.put("method", methodName)
                        logRpc(true, requestJson)
                        responseText.append("Usage: admit <name> <seed_index> <expected_hash>")
                        responseJson.put("error", JSONObject().apply { put("code", -32602); put("message", "Invalid params") })
                        logRpc(false, responseJson)
                    } else {
                        val name = parts[1]
                        val seed = parts[2]
                        val expectedH = parts[3]
                        
                        paramsJson.put("name", name)
                        paramsJson.put("seed", seed)
                        paramsJson.put("hash", expectedH)
                        
                        requestJson.put("method", methodName)
                        requestJson.put("params", paramsJson)
                        logRpc(true, requestJson)
                        
                        responseText.append("[*] Evaluating Reconstruction Contract K_D for: $name...\n")
                        val res = brainkRuntime.admitCapability(name, seed, expectedH)
                        responseText.append("[*] Response: ${res["status"]}\n")
                        responseText.append("  - Details: ${res["message"] ?: "Admitted to system bus."}")
                        
                        responseJson.put("result", JSONObject(res))
                        logRpc(false, responseJson)
                    }
                }
                "ingest" -> {
                    val mode = parts.getOrNull(1)?.lowercase() ?: "code"
                    methodName = when (mode) {
                        "hardware" -> "ingest_hardware_runtime"
                        "semantic", "encyclopedias", "knowledge" -> "ingest_semantic_knowledge"
                        else -> "ingest_host_codebase"
                    }
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    if (mode == "semantic" || mode == "encyclopedias" || mode == "knowledge") {
                        val knowledgeIngestor = KnowledgeIngestionService(getApplication(), brainkRuntime)
                        val semResult = knowledgeIngestor.ingestKnowledgeBase()
                        
                        responseText.append("[+] SEMANTIC INGESTION COMPLETE.\n")
                        responseText.append("  - Status: ${semResult.status}\n")
                        responseText.append("  - Vectors Loaded: ${semResult.vectorsLoaded}\n")
                        responseText.append("  - Concepts Mapped: ${semResult.conceptsMapped}\n")
                        responseText.append("  - Details: ${semResult.message}\n")
                        responseText.append("  - LEDGER & MATH Lanes expanded for lexical weights.\n")
                        responseText.append("  - Skill 'SEMANTIC_AWARENESS' Admitted to Runtime.\n")
                        
                        codebaseContext += "\n\n[SEMANTIC KNOWLEDGE UPDATE]\nYou have been fed vast encyclopedias and definitional lexicons. You now possess deep, structured semantic knowledge across all domains."
                        
                        responseJson.put("result", JSONObject().apply { 
                            put("status", semResult.status)
                            put("mode", mode)
                            put("vectors_loaded", semResult.vectorsLoaded)
                            put("concepts_mapped", semResult.conceptsMapped)
                        })
                    } else {
                        val ingestor = HostCodebaseIngestor(getApplication(), brainkRuntime)
                        val result = if (mode == "hardware") ingestor.ingestHardware() else ingestor.ingest()
                        
                        if (result.success) {
                            if (mode == "hardware") {
                                codebaseContext += "\n\n" + result.contextString + "\n\n[DETECTED HARDWARE OPTIMIZATION TARGETS]\n" + result.detectedPatterns.joinToString("\n") { "- $it" }
                                
                                responseText.append("[+] HARDWARE RUNTIME INGESTED INTO LEARNING LOOP.\n")
                                responseText.append("  - Module: Dalvik/ART Sandbox & Kernel Telemetry\n")
                                responseText.append("  - Metrics Captured: Hardware ABIs, CPU Cores, Memory State\n")
                                if (result.detectedPatterns.isNotEmpty()) {
                                    responseText.append("  - Simulated Overdrive Targets: ${result.detectedPatterns.joinToString(", ")}\n")
                                }
                                responseText.append("  - Skill 'HARDWARE_OVERDRIVE' Admitted to Runtime.\n")
                                responseText.append("  - Math Lane Expanded based on Logical Core topology.\n")
                                responseText.append("  - Agent primed for deep-system optimization.\n")
                            } else {
                                codebaseContext = result.contextString + "\n\n[DETECTED ARCHITECTURAL PATTERNS]\n" + result.detectedPatterns.joinToString("\n") { "- $it" }
                                
                                responseText.append("[+] HOST CODEBASE INGESTED INTO LEARNING LOOP.\n")
                                responseText.append("  - Module: com.example\n")
                                responseText.append("  - Files Assessed: ${result.fileCount}\n")
                                responseText.append("  - Logic Lines: ${result.totalLines}\n")
                                if (result.detectedPatterns.isNotEmpty()) {
                                    responseText.append("  - Detected Patterns: ${result.detectedPatterns.joinToString(", ")}\n")
                                }
                                responseText.append("  - Skill 'HOST_OPTIMIZATION' Admitted to Runtime.\n")
                                responseText.append("  - Code Lane Expanded by ${result.totalLines}.\n")
                                responseText.append("  - Ready for computational optimization.\n")
                            }
                            responseJson.put("result", JSONObject().apply { 
                                put("status", "INGESTED")
                                put("mode", mode)
                                put("lines", result.totalLines)
                                put("patterns", org.json.JSONArray(result.detectedPatterns))
                            })
                        } else {
                            responseText.append("[-] IO FAILURE ON BUS: ${result.errorMessage}")
                            responseJson.put("error", JSONObject().apply { put("message", result.errorMessage ?: "Unknown error") })
                        }
                    }
                    
                    logRpc(false, responseJson)
                }
                "diagnose", "gates" -> {
                    methodName = "evaluate_gates"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    val report = kotlinx.coroutines.runBlocking { repository.runGateEvaluation(getApplication()) }
                    _gateMatrixReport.value = report
                    
                    responseText.append("=== KEX FAIL-CLOSED GATE MATRIX (G0..G8) EVALUATION ===\n")
                    responseText.append("VERDICT: ${if (report.passed) "PASSED [EMPIRICALLY_VERIFIED]" else "HALTED AT ${report.failureGate} [FAIL-CLOSED]"}\n")
                    responseText.append("TOTAL DURATION: ${String.format(java.util.Locale.US, "%.2f", report.totalDurationNs / 1_000_000.0)} ms\n\n")
                    
                    report.results.forEach { gate ->
                        val icon = when (gate.status) {
                            GateStatus.PASSED -> "[+]"
                            GateStatus.FAILED -> "[-]"
                            GateStatus.BLOCKED -> "[*]"
                        }
                        responseText.append("$icon ${gate.gateId} (${gate.name}): ${gate.status}\n")
                        responseText.append("    ${gate.details} (${gate.durationNs / 1_000} µs)\n")
                    }
                    
                    responseJson.put("result", JSONObject().apply {
                        put("passed", report.passed)
                        put("failure_gate", report.failureGate ?: "NONE")
                        put("duration_ns", report.totalDurationNs)
                    })
                    logRpc(false, responseJson)
                }
                "hypotheses", "benchmark" -> {
                    methodName = "run_hypotheses_benchmark"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    val results = KexHypothesisEngine.runAllHypotheses()
                    _hypothesisResults.value = results
                    _fourPlaneState.value = KexHypothesisEngine.sampleFourPlaneState()
                    
                    responseText.append("=== KEDDEH 8-HYPOTHESIS ENTERPRISE BENCHMARK RESULTS ===\n")
                    results.forEach { h ->
                        val icon = if (h.passed) "[+]" else "[-]"
                        responseText.append("$icon ${h.hypothesisId}: ${h.name} -> ${if (h.passed) "PASSED" else "FAILED"}\n")
                        responseText.append("    Claim:  ${h.targetClaim}\n")
                        responseText.append("    Metric: ${h.measuredMetric}\n")
                    }
                    
                    responseJson.put("result", JSONObject().apply {
                        put("all_passed", results.all { it.passed })
                        put("tests_count", results.size)
                    })
                    logRpc(false, responseJson)
                }
                "governance", "arb", "funding" -> {
                    methodName = "execute_weaponized_governance_audit"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    val report = kotlinx.coroutines.runBlocking { repository.runGovernanceEvaluation(getApplication()) }
                    _governanceReport.value = report
                    
                    responseText.append("=== WEAPONIZED ARCHITECTURE & MANDATORY GOVERNANCE AUDIT ===\n")
                    responseText.append("CAPITAL GUARDED:   $${String.format(java.util.Locale.US, "%,.2f", report.totalCapitalGuardedUsd)}\n")
                    responseText.append("CAPITAL APPROVED:  $${String.format(java.util.Locale.US, "%,.2f", report.totalCapitalApprovedUsd)}\n")
                    responseText.append("CAPITAL DEFUNDED:  $${String.format(java.util.Locale.US, "%,.2f", report.totalCapitalDefundedUsd)} (Fail-Closed Gates Enforced)\n")
                    responseText.append("LICENSING SAVINGS: $${String.format(java.util.Locale.US, "%,.2f", report.totalLicensingSavingsUsd)}/yr (Portfolio Rationalized)\n")
                    responseText.append("TECH DEBT SCORE:   ${String.format(java.util.Locale.US, "%.1f", report.techDebtAudit.totalDebtScore)}/100\n\n")
                    
                    responseText.append("--- PILLAR 1: ARB FUNDING DECISIONS ---\n")
                    report.arbEvaluations.forEach { r ->
                        val icon = if (r.fundingVerdict == FundingGateVerdict.FUNDED_ALLOCATION_APPROVED) "[+]" else "[-]"
                        responseText.append("$icon ${r.proposal.projectId}: ${r.proposal.projectName} -> ${r.fundingVerdict}\n")
                        responseText.append("    Approved: $${String.format(java.util.Locale.US, "%,.2f", r.allocatedCapitalUsd)} (Requested: $${String.format(java.util.Locale.US, "%,.2f", r.proposal.requestedCapitalUsd)})\n")
                        responseText.append("    Justification: ${r.justification}\n")
                        responseText.append("    Voucher: ${r.voucherHash.take(16)}...\n")
                    }
                    
                    responseText.append("\n--- PILLAR 2: GOLDEN PATH BLUEPRINTS ---\n")
                    report.goldenPaths.forEach { gp ->
                        responseText.append("[+] ${gp.templateId}: ${gp.name} (${gp.category})\n")
                        responseText.append("    Security: ${gp.builtInSecurity}\n")
                        responseText.append("    Logging:  ${gp.builtInLogging}\n")
                    }
                    
                    responseText.append("\n--- PILLAR 3: BUY VS BUILD & PORTFOLIO RATIONALIZATION ---\n")
                    report.vendorEvaluations.forEach { v ->
                        val icon = if (v.status == ProcurementStatus.APPROVED_FOR_PROCUREMENT) "[+]" else "[-]"
                        responseText.append("$icon ${v.vendorName} (${v.productName}): ${v.status}\n")
                        responseText.append("    Audit: ${v.auditNotes}\n")
                    }
                    responseText.append("Savings: $${String.format(java.util.Locale.US, "%,.2f", report.portfolioRationalization.projectedAnnualSavingsUsd)}/yr across ${report.portfolioRationalization.totalRedundantToolsIdentified} redundant tools.\n")
                    
                    responseText.append("\n--- PILLAR 4: NORTH STAR ROADMAP & TECH DEBT ---\n")
                    report.techDebtAudit.highestRiskBlockers.forEach { d ->
                        responseText.append("[-] ${d.systemId} (${d.systemName}): Score ${d.techDebtScore}/100, Drag $${String.format(java.util.Locale.US, "%,.0f", d.annualMaintenanceDragUsd)}/yr\n")
                        responseText.append("    Modernization: ${d.modernizationProposal}\n")
                    }
                    
                    responseJson.put("result", JSONObject().apply {
                        put("capital_guarded_usd", report.totalCapitalGuardedUsd)
                        put("capital_approved_usd", report.totalCapitalApprovedUsd)
                        put("capital_defunded_usd", report.totalCapitalDefundedUsd)
                        put("licensing_savings_usd", report.totalLicensingSavingsUsd)
                        put("tech_debt_score", report.techDebtAudit.totalDebtScore)
                    })
                    logRpc(false, responseJson)
                }
                "goldenpath" -> {
                    methodName = "list_golden_path_blueprints"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    val blueprints = KexWeaponizedGovernance.getGoldenPathBlueprints()
                    responseText.append("=== KEX GOLDEN PATH COMPLIANT BLUEPRINTS ===\n")
                    blueprints.forEach { gp ->
                        responseText.append("[+] ${gp.templateId}: ${gp.name} (${gp.category})\n")
                        responseText.append("    Guarantee: ${gp.complianceGuarantee}\n")
                        responseText.append("    Security:  ${gp.builtInSecurity}\n")
                        responseText.append("    Logging:   ${gp.builtInLogging}\n")
                        responseText.append("    Gates:     ${gp.builtInGates}\n")
                        responseText.append("    Scaffold:  ${gp.deploymentScaffoldScript}\n\n")
                    }
                    
                    responseJson.put("result", JSONObject().apply {
                        put("blueprints_count", blueprints.size)
                    })
                    logRpc(false, responseJson)
                }
                "procurement", "vendor" -> {
                    methodName = "audit_procurement_and_rationalization"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    val vendors = KexWeaponizedGovernance.evaluateVendorSoftware()
                    val portfolio = KexWeaponizedGovernance.rationalizePortfolio()
                    
                    responseText.append("=== PROCUREMENT 'BUY VS BUILD' & PORTFOLIO RATIONALIZATION ===\n")
                    vendors.forEach { v ->
                        val icon = if (v.status == ProcurementStatus.APPROVED_FOR_PROCUREMENT) "[+]" else "[-]"
                        responseText.append("$icon ${v.vendorName} - ${v.productName} (${v.category})\n")
                        responseText.append("    Status: ${v.status} | Cost: $${String.format(java.util.Locale.US, "%,.2f", v.annualLicensingCostUsd)}/yr\n")
                        responseText.append("    Notes:  ${v.auditNotes}\n")
                    }
                    
                    responseText.append("\nPORTFOLIO RATIONALIZATION & REDUNDANCY ELIMINATION:\n")
                    portfolio.items.forEach { item ->
                        responseText.append("  * Redundant: ${item.toolName} (${item.vendor}) -> $${String.format(java.util.Locale.US, "%,.2f", item.annualCostUsd)}/yr\n")
                        responseText.append("    Replacement: ${item.targetStandardReplacement}\n")
                    }
                    responseText.append("\nPROJECTED ANNUAL SAVINGS: $${String.format(java.util.Locale.US, "%,.2f", portfolio.projectedAnnualSavingsUsd)}/yr\n")
                    
                    responseJson.put("result", JSONObject().apply {
                        put("vendors_evaluated", vendors.size)
                        put("redundant_tools_count", portfolio.totalRedundantToolsIdentified)
                        put("projected_annual_savings_usd", portfolio.projectedAnnualSavingsUsd)
                    })
                    logRpc(false, responseJson)
                }
                "techdebt", "roadmap" -> {
                    methodName = "audit_tech_debt_and_north_star"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    val roadmaps = KexWeaponizedGovernance.generateNorthStarRoadmaps()
                    val debt = KexWeaponizedGovernance.auditSystemicTechDebt()
                    
                    responseText.append("=== NORTH STAR ROADMAP GUIDES ===\n")
                    roadmaps.forEach { r ->
                        responseText.append("[+] ${r.businessFeature} (Requested by: ${r.requestedBy})\n")
                        responseText.append("    Fastest Path: ${r.fastestScalablePath}\n")
                        responseText.append("    Leverages:    ${r.goldenPathToLeverage} (${String.format(java.util.Locale.US, "%.0f", r.estimatedTtmReductionPercent)}% TTM Reduction)\n\n")
                    }
                    
                    responseText.append("=== SYSTEMIC TECH DEBT REMOVAL AUDIT ===\n")
                    debt.highestRiskBlockers.forEach { d ->
                        responseText.append("[-] ${d.systemId}: ${d.systemName} (Debt Score: ${d.techDebtScore}/100, Risk: ${d.growthBlockingFactor})\n")
                        responseText.append("    Drag:          $${String.format(java.util.Locale.US, "%,.0f", d.annualMaintenanceDragUsd)}/yr\n")
                        responseText.append("    Modernization: ${d.modernizationProposal}\n")
                        responseText.append("    Executive ROI: ${d.executiveRoiJustification}\n\n")
                    }
                    responseText.append("EXECUTIVE SUMMARY:\n${debt.executiveSummary}\n")
                    
                    responseJson.put("result", JSONObject().apply {
                        put("average_debt_score", debt.totalDebtScore)
                        put("total_maintenance_drag_usd", debt.totalAnnualMaintenanceDragUsd)
                        put("roadmaps_count", roadmaps.size)
                    })
                    logRpc(false, responseJson)
                }
                "fn_arb" -> {
                    methodName = "execute_fn_convene_arb"
                    val pId = if (parts.size > 1) parts[1] else "PROJ-CUSTOM"
                    val budget = if (parts.size > 2) parts[2].toDoubleOrNull() ?: 500000.0 else 500000.0
                    val hasBp = if (parts.size > 3) parts[3].toBooleanStrictOrNull() ?: true else true
                    
                    val receipt = KexGovernanceFunctions.conveneArbReview(
                        projectId = pId,
                        projectName = "Custom Evaluation Unit",
                        requestedBudgetUsd = budget,
                        architect = "Lead Architect",
                        hasBlueprint = hasBp,
                        techStack = listOf(
                            TechStackAlignment("Compute", "Kotlin 2.0 / Coroutines", "Kotlin / Coroutines", true),
                            TechStackAlignment("RPC", "gRPC / Protobuf", "gRPC / Protobuf", true),
                            TechStackAlignment("Persistence", "Room SQLite Injective Engine", "Room SQLite Injective Engine", true)
                        )
                    )
                    val auth = KexGovernanceFunctions.authorizeBudgetRelease(receipt)
                    
                    kotlinx.coroutines.runBlocking {
                        repository.recordGovernanceAction("FN_CONVENE_ARB", JSONObject().apply {
                            put("project_id", pId)
                            put("verdict", receipt.fundingVerdict.name)
                            put("allocated_usd", receipt.allocatedCapitalUsd)
                            put("voucher_hash", receipt.voucherHash)
                            put("auth_signature", auth.signatureDigest)
                        })
                    }
                    
                    responseText.append("=== FUNCTION: conveneArbReview() & authorizeBudgetRelease() ===\n")
                    responseText.append("  - Project ID:     ${receipt.proposal.projectId}\n")
                    responseText.append("  - Requested:      $${String.format(java.util.Locale.US, "%,.2f", receipt.proposal.requestedCapitalUsd)}\n")
                    responseText.append("  - ARB Status:     ${receipt.reviewStatus}\n")
                    responseText.append("  - Gate Verdict:   ${receipt.fundingVerdict}\n")
                    responseText.append("  - Allocated:      $${String.format(java.util.Locale.US, "%,.2f", receipt.allocatedCapitalUsd)}\n")
                    responseText.append("  - Voucher SHA256: ${receipt.voucherHash}\n")
                    responseText.append("  - Auth Signature: ${auth.signatureDigest}\n")
                    responseText.append("  - Justification:  ${receipt.justification}\n")
                    responseText.append("  - Receipt:        Committed to Room as EMPIRICALLY_VERIFIED")
                    
                    responseJson.put("result", JSONObject().apply {
                        put("verdict", receipt.fundingVerdict.name)
                        put("allocated_usd", receipt.allocatedCapitalUsd)
                        put("voucher_hash", receipt.voucherHash)
                        put("signature", auth.signatureDigest)
                    })
                    logRpc(false, responseJson)
                }
                "fn_scaffold" -> {
                    methodName = "execute_fn_scaffold_golden_path"
                    val tId = if (parts.size > 1) parts[1] else "GP-SVC-01"
                    val sName = if (parts.size > 2) parts[2] else "microservice-alpha"
                    
                    val scaffoldDir = File(getApplication<Application>().filesDir, "scaffolds/$sName")
                    val result = KexGovernanceFunctions.scaffoldGoldenPath(tId, sName, scaffoldDir)
                    
                    kotlinx.coroutines.runBlocking {
                        repository.recordGovernanceAction("FN_SCAFFOLD", JSONObject().apply {
                            put("template_id", tId)
                            put("service_name", sName)
                            put("files_generated", result.generatedFiles.size)
                            put("total_bytes", result.totalBytesGenerated)
                            put("tree_digest", result.treeDigestSha256)
                        })
                    }
                    
                    responseText.append("=== FUNCTION: scaffoldGoldenPath() ===\n")
                    responseText.append("  - Template ID:    ${result.templateId}\n")
                    responseText.append("  - Service Name:   ${result.serviceName}\n")
                    responseText.append("  - Destination:    ${result.destinationPath}\n")
                    responseText.append("  - Files Created:  ${result.generatedFiles.size} physical files written\n")
                    responseText.append("  - Total Bytes:    ${result.totalBytesGenerated} bytes\n")
                    responseText.append("  - Tree Digest:    ${result.treeDigestSha256}\n")
                    responseText.append("  - Compliance:     ${if (result.compliancePassed) "100% BY CONSTRUCTION" else "FAILED"}\n\n")
                    responseText.append("SCAFFOLDED FILES:\n")
                    result.generatedFiles.forEach { f ->
                        responseText.append("  * ${f.relativePath} (${f.fileSizeBytes} B) -> SHA: ${f.sha256Digest.take(16)}...\n")
                    }
                    
                    responseJson.put("result", JSONObject().apply {
                        put("files_count", result.generatedFiles.size)
                        put("total_bytes", result.totalBytesGenerated)
                        put("tree_digest", result.treeDigestSha256)
                    })
                    logRpc(false, responseJson)
                }
                "fn_filter" -> {
                    methodName = "execute_fn_evaluate_buy_vs_build"
                    val vName = if (parts.size > 1) parts[1] else "AcmeCorp"
                    val pName = if (parts.size > 2) parts[2] else "CustomDb"
                    val protos = if (parts.size > 3) parts[3].split(",") else listOf("HTTP/1.1", "CustomBinary")
                    
                    val input = VendorEvaluationInput(
                        vendorName = vName,
                        productName = pName,
                        category = "Data Persistence",
                        annualCostUsd = 175000.0,
                        supportedProtocols = protos,
                        isOpenStandard = protos.any { it.contains("gRPC") || it.contains("POSIX") },
                        supportsZeroTrustAuth = protos.any { it.contains("OIDC") || it.contains("OAuth") }
                    )
                    val result = KexGovernanceFunctions.evaluateBuyVsBuildFilter(input)
                    
                    responseText.append("=== FUNCTION: evaluateBuyVsBuildFilter() ===\n")
                    responseText.append("  - Vendor:       ${result.vendorName} (${result.productName})\n")
                    responseText.append("  - Cost:         $${String.format(java.util.Locale.US, "%,.2f", result.annualLicensingCostUsd)}/yr\n")
                    responseText.append("  - Status:       ${result.status}\n")
                    responseText.append("  - Wire Compliant: ${result.supportsStandardProtocols}\n")
                    responseText.append("  - Missing Standards: ${if (result.requiredStandardsMissing.isEmpty()) "NONE" else result.requiredStandardsMissing.joinToString(", ")}\n")
                    responseText.append("  - Audit Notes:  ${result.auditNotes}\n")
                    
                    responseJson.put("result", JSONObject().apply {
                        put("status", result.status.name)
                        put("compliant", result.targetArchitectureCompliant)
                    })
                    logRpc(false, responseJson)
                }
                "fn_debt" -> {
                    methodName = "execute_fn_compute_systemic_tech_debt_score"
                    val sId = if (parts.size > 1) parts[1] else "LEGACY-SYS-X"
                    val cost = if (parts.size > 2) parts[2].toDoubleOrNull() ?: 150000.0 else 150000.0
                    val incidents = if (parts.size > 3) parts[3].toIntOrNull() ?: 6 else 6
                    
                    val input = LegacyAuditInput(
                        systemId = sId,
                        systemName = "Legacy Core Gateway",
                        annualMaintenanceUsd = cost,
                        incidentCountLastYear = incidents,
                        blocksMultiRegion = true,
                        blocksScale = true,
                        hasAutomatedTests = false
                    )
                    val result = KexGovernanceFunctions.computeSystemicTechDebtScore(input)
                    
                    responseText.append("=== FUNCTION: computeSystemicTechDebtScore() ===\n")
                    responseText.append("  - System ID:    ${result.systemId}\n")
                    responseText.append("  - Debt Score:   ${result.techDebtScore} / 100\n")
                    responseText.append("  - Risk Factor:  ${result.growthBlockingFactor}\n")
                    responseText.append("  - Annual Drag:  $${String.format(java.util.Locale.US, "%,.2f", result.annualMaintenanceDragUsd)}/yr\n")
                    responseText.append("  - Modernization: ${result.modernizationProposal}\n")
                    responseText.append("  - Executive ROI: ${result.executiveRoiJustification}\n")
                    
                    responseJson.put("result", JSONObject().apply {
                        put("debt_score", result.techDebtScore)
                        put("risk_factor", result.growthBlockingFactor)
                        put("annual_drag_usd", result.annualMaintenanceDragUsd)
                    })
                    logRpc(false, responseJson)
                }
                "align" -> {
                    methodName = "force_lane_alignment"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    selfRepairDaemon.forceAlignment()
                    
                    responseText.append("[+] ALIGNMENT DIRECTIVE EXECUTED.\n")
                    responseText.append("  - Memory lanes stabilized and truncated to stable harmonics.\n")
                    responseText.append("  - Volatile obligations purged.\n")
                    responseText.append("  - Hardware telemetry baseline recalibrated.\n")
                    
                    responseJson.put("result", JSONObject().apply {
                        put("status", "ALIGNED")
                    })
                    
                    logRpc(false, responseJson)
                }
                "validate" -> {
                    methodName = "validate_cognitive_integrity"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    cognitiveIntegrityMonitor.forceValidation()
                    
                    responseText.append("[+] COGNITIVE VALIDATION DIRECTIVE DISPATCHED.\n")
                    responseText.append("  - Awaiting async validation report from SeedUnpacker utility...\n")
                    
                    responseJson.put("result", JSONObject().apply {
                        put("status", "VALIDATING")
                    })
                    
                    logRpc(false, responseJson)
                }
                "status" -> {
                    methodName = "get_telemetry"
                    requestJson.put("method", methodName)
                    logRpc(true, requestJson)
                    
                    val am = getApplication<Application>().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    val memInfo = ActivityManager.MemoryInfo()
                    am.getMemoryInfo(memInfo)
                    val statFs = StatFs(getApplication<Application>().filesDir.path)
                    val seedReceipt = KexSeedAuthority.verify()
                    
                    responseText.append("=== SYSTEM TELEMETRY (GENUINE HARDWARE & OS MEASUREMENTS) ===\n")
                    responseText.append("  - Boot State:       ${brainkRuntime.bootState}\n")
                    responseText.append("  - PLL Lock:         ${brainkRuntime.pllLock}\n")
                    responseText.append("  - Seed Authority:   ${seedReceipt.hexString} (${seedReceipt.asciiPrefix} Baseline)\n")
                    responseText.append("  - VFD Strand:       ${seedReceipt.vfdStrandLength} digits (Computed)\n")
                    responseText.append("  - Total RAM:        ${memInfo.totalMem / (1024 * 1024)} MB\n")
                    responseText.append("  - Available RAM:    ${memInfo.availMem / (1024 * 1024)} MB\n")
                    responseText.append("  - Low Memory State: ${memInfo.lowMemory}\n")
                    responseText.append("  - Free Disk Space:  ${statFs.availableBytes / (1024 * 1024)} MB\n")
                    responseText.append("  - Total Disk Space: ${statFs.totalBytes / (1024 * 1024)} MB\n")
                    responseText.append("  - Logical CPU Cores: ${Runtime.getRuntime().availableProcessors()}\n")
                    responseText.append("  - JVM Used Heap:    ${(Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024)} MB\n")
                    responseText.append("  - JVM Max Heap:     ${Runtime.getRuntime().maxMemory() / (1024 * 1024)} MB\n")
                    
                    val telemetryMap = mapOf(
                        "total_ram_mb" to (memInfo.totalMem / (1024 * 1024)),
                        "avail_ram_mb" to (memInfo.availMem / (1024 * 1024)),
                        "free_disk_mb" to (statFs.availableBytes / (1024 * 1024)),
                        "cpu_cores" to Runtime.getRuntime().availableProcessors(),
                        "strand_length" to seedReceipt.vfdStrandLength
                    )
                    
                    responseJson.put("result", JSONObject(telemetryMap))
                    logRpc(false, responseJson)
                }
            }
        } catch (e: Exception) {
            responseText.append("[-] FATAL EXCEPTION: ${e.message}")
            responseJson.put("error", JSONObject().apply { put("code", -32603); put("message", "Internal error: ${e.message}") })
            logRpc(false, responseJson)
        }
        
        updateTelemetry()
        
        _messages.update { it + ChatMessage(text = responseText.toString(), isFromUser = false) }
        _isTyping.value = false
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        
        val userMessage = ChatMessage(text = text.trim(), isFromUser = true)
        _messages.update { it + userMessage }
        _isTyping.value = true

        val commandParts = text.trim().split("\\s+".toRegex())
        val cmd = commandParts[0].lowercase()
        
        val routeResult = kexKernel.routeAgentExecution(cmd, text.trim())
        if (!routeResult.success) {
            _messages.update { it + ChatMessage(id = java.util.UUID.randomUUID().toString(), text = routeResult.message, isFromUser = false) }
            _isTyping.value = false
            return
        }

        if (cmd in listOf("boot", "wire", "send", "admit", "status", "help", "ingest", "diagnose", "gates", "align", "validate", "inject", "switch", "sentinel", "v3_status", "claim", "query", "checkpoint")) {
            handleBrainkCommand(cmd, commandParts, text.trim(), routeResult.message)
            return
        }

        if (cmd == "infer") {
            _messages.update { it + ChatMessage(id = java.util.UUID.randomUUID().toString(), text = "[${routeResult.message}]\n\nInitiating LLM inference using ${_activeProvider.value.name}...", isFromUser = false) }
            viewModelScope.launch {
                val responseId = java.util.UUID.randomUUID().toString()
                _messages.update { it + ChatMessage(id = responseId, text = "", isFromUser = false, isStreaming = true) }
                
                kernelTelemetryService.setThoughtProcess("SYNTHESIZING VFD INFERENCE (${_activeProvider.value.name})...", true)

                try {
                    val request = ModelRequest(
                        history = _messages.value.filter { !it.isStreaming && it.id != responseId }.map { it },
                        systemInstruction = systemInstructionText,
                        context = codebaseContext
                    )

                    withContext(Dispatchers.IO) {
                        _activeProvider.value.generateStream(request).collect { newText ->
                            withContext(Dispatchers.Main) {
                                _messages.update { currentList ->
                                    currentList.map {
                                        if (it.id == responseId) {
                                            it.copy(text = it.text + newText)
                                        } else {
                                            it
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        _messages.update { currentList ->
                            currentList.map {
                                if (it.id == responseId) {
                                    it.copy(text = "Error: ${e.message}")
                                } else {
                                    it
                                }
                            }
                        }
                    }
                } finally {
                    kernelTelemetryService.setThoughtProcess("IDLE (Listening)", false)
                    withContext(Dispatchers.Main) {
                        _isTyping.value = false
                        _messages.update { currentList ->
                            currentList.map {
                                if (it.id == responseId) {
                                    it.copy(isStreaming = false)
                                } else {
                                    it
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
