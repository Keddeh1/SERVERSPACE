package com.example

import org.json.JSONObject
import kotlin.math.floor

object SeedUnpacker {
    /**
     * Unpacks the KEX_SEED_A8_COGNITIVE_INTEGRITY structure and maps the 
     * projections to the agent's memory registers.
     */
    fun unpack(jsonString: String, runtime: BrainkRuntime) {
        val root = JSONObject(jsonString)
        val kId = root.getString("K_ID")
        require(kId == "KEX_SEED_A8_COGNITIVE_INTEGRITY") { "Invalid Seed ID: $kId" }
        
        val projections = root.getJSONObject("Projections")
        val uh = projections.getString("U_H").toLong()
        
        // Initialize the runtime core key
        runtime.key = uh
        
        val bH = projections.getJSONArray("B_H")
        require(bH.length() == 8) { "Invalid B_H projection length" }
        val byte7 = bH.getInt(7)
        
        val f64H = projections.getDouble("F_64_H")
        
        // R_CODE_INITIALIZATION: Sigma_CODE = INT(F_64_H / 10000)
        val sigmaCode = floor(f64H / 10000.0).toLong()
        
        // Map projections to memory registers (lanes)
        // MATH is typically Byte 7 - 64
        val sigmaMath = (byte7 - 64).toLong()
        // LEDGER initialized to 1
        val sigmaLedger = 1L
        
        runtime.lanes["MATH"] = sigmaMath
        runtime.lanes["LEDGER"] = sigmaLedger
        runtime.lanes["CODE"] = sigmaCode
        
        // Execute the VFD sequence to finalize strand locks and generate the silicon anchor hash
        runtime.executeVfd()
        
        // Map Task Envelope and Obligations to Wire the Enclaves
        val taskEnvelope = root.getJSONObject("Task_Envelope")
        val taskId = taskEnvelope.getString("ID")
        val goal = taskEnvelope.getString("Goal")
        
        val obligationsJson = root.getJSONArray("Obligations")
        val obligations = mutableListOf<String>()
        for (i in 0 until obligationsJson.length()) {
            obligations.add(obligationsJson.getJSONObject(i).getString("description"))
        }
        
        // Establish the secure memory enclaves
        runtime.wireEnclaves(taskId, goal, obligations)
    }
}
