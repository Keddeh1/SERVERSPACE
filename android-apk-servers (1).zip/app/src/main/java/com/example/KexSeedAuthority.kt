package com.example

import java.nio.ByteBuffer
import java.security.MessageDigest
import kotlin.math.floor
import kotlin.math.log10

data class SeedVerificationReceipt(
    val seedDecimal: Long,
    val hexString: String,
    val rawBytes: List<Int>,
    val asciiPrefix: String,
    val anchorChar: Char,
    val bypassIndex: Int,
    val float64Value: Double,
    val laneMath: Long,
    val laneLedger: Long,
    val laneCode: Long,
    val vfdStrandLength: Int,
    val spatialUpper: Double,
    val spatialLower: Double,
    val sha256Digest: String,
    val isValid: Boolean,
    val executionDurationNs: Long
)

object KexSeedAuthority {
    const val A8_SEED_DECIMAL: Long = 4696753037434160968L
    const val EXPECTED_PREFIX: String = "A.8"
    const val EXPECTED_ANCHOR: Char = 'H'
    const val EXPECTED_BYPASS_INDEX: Int = 7
    const val EXPECTED_STRAND_LENGTH: Int = 106977
    const val SPATIAL_UPPER: Double = 10.888442
    const val SPATIAL_LOWER: Double = -6587044.0

    /**
     * Executes the mathematical and cryptographic verification of the KEX seed.
     * Extracts byte projections, IEEE 754 float representation, register lanes,
     * and computes the logarithmic VFD strand length deterministically.
     */
    fun verify(seedDecimal: Long = A8_SEED_DECIMAL): SeedVerificationReceipt {
        val startNs = System.nanoTime()

        // 1. Raw 8-byte extraction (Big-Endian)
        val buffer = ByteBuffer.allocate(8).putLong(seedDecimal)
        val byteArr = buffer.array()
        val rawBytes = byteArr.map { it.toInt() and 0xFF }

        // 2. ASCII Prefix (Bytes 0..2) and Anchor (Byte 7)
        val asciiPrefix = "${byteArr[0].toInt().toChar()}${byteArr[1].toInt().toChar()}${byteArr[2].toInt().toChar()}"
        val anchorChar = byteArr[7].toInt().toChar()
        val bypassIndex = rawBytes[6]

        // 3. IEEE 754 64-bit float representation
        val float64Value = java.lang.Double.longBitsToDouble(seedDecimal)

        // 4. Deterministic register lanes
        val laneMath = (rawBytes[7] - 64).toLong() // 72 - 64 = 8
        val laneLedger = 1L
        val laneCode = floor(float64Value / 10000.0).toLong() // floor(990208.39 / 10000) = 99

        // 5. Deterministic Logarithmic VFD Strand Length calculation
        var logP = 0.0
        for (k in 2..10000) {
            logP += log10(k.toDouble())
        }
        logP -= log10(8.0)

        val mathLen = floor(log10(laneMath.toDouble()) + logP).toInt() + 1
        val ledgerLen = floor(log10(laneLedger.toDouble()) + logP).toInt() + 1
        val codeLen = floor(log10(laneCode.toDouble()) + logP).toInt() + 1
        val vfdStrandLength = (mathLen + ledgerLen + codeLen) - 3

        // 6. Cryptographic SHA-256 Digest of canonical representation
        val canonicalPayload = "authority=KEX_SEED_A8_COGNITIVE_INTEGRITY:seed=$seedDecimal:prefix=$asciiPrefix:anchor=$anchorChar:vfd=$vfdStrandLength"
        val md = MessageDigest.getInstance("SHA-256")
        val digestBytes = md.digest(canonicalPayload.toByteArray(Charsets.UTF_8))
        val sha256Digest = digestBytes.joinToString("") { "%02x".format(it) }

        // 7. Validation predicate
        val isValid = (asciiPrefix == EXPECTED_PREFIX) &&
                (anchorChar == EXPECTED_ANCHOR) &&
                (bypassIndex == EXPECTED_BYPASS_INDEX) &&
                (vfdStrandLength == EXPECTED_STRAND_LENGTH)

        val durationNs = System.nanoTime() - startNs

        return SeedVerificationReceipt(
            seedDecimal = seedDecimal,
            hexString = "0x" + "%016X".format(seedDecimal),
            rawBytes = rawBytes,
            asciiPrefix = asciiPrefix,
            anchorChar = anchorChar,
            bypassIndex = bypassIndex,
            float64Value = float64Value,
            laneMath = laneMath,
            laneLedger = laneLedger,
            laneCode = laneCode,
            vfdStrandLength = vfdStrandLength,
            spatialUpper = SPATIAL_UPPER,
            spatialLower = SPATIAL_LOWER,
            sha256Digest = sha256Digest,
            isValid = isValid,
            executionDurationNs = durationNs
        )
    }
}
