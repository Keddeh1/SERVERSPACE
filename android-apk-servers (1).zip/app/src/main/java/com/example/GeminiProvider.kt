package com.example

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

class GeminiProvider(private val apiKey: String) : ModelProvider {
    override val name: String = "Google Gemini (Baseline)"

    override suspend fun generateStream(request: ModelRequest): Flow<String> = flow {
        val history = request.history.map { msg ->
            Content(
                role = if (msg.isFromUser) "user" else "model",
                parts = listOf(Part(text = msg.text))
            )
        }

        val fullInstruction = request.systemInstruction + 
            if (request.context.isNotEmpty()) "\n\n[HOST CODEBASE CONTEXT]\n${request.context}" else ""
            
        val generateRequest = GenerateContentRequest(
            contents = history,
            systemInstruction = Content(parts = listOf(Part(text = fullInstruction)))
        )

        val response = RetrofitClient.service.generateContentStream(apiKey, generateRequest)
        
        response.byteStream().bufferedReader().use { reader ->
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                if (line!!.startsWith("data: ")) {
                    val jsonStr = line!!.substring(6).trim()
                    if (jsonStr == "[DONE]") continue
                    try {
                        val chunk = Json.parseToJsonElement(jsonStr).jsonObject
                        val newText = chunk["candidates"]?.jsonArray
                            ?.getOrNull(0)?.jsonObject
                            ?.get("content")?.jsonObject
                            ?.get("parts")?.jsonArray
                            ?.getOrNull(0)?.jsonObject
                            ?.get("text")?.jsonPrimitive?.content ?: ""
                        
                        if (newText.isNotEmpty()) {
                            emit(newText)
                        }
                    } catch (e: Exception) {
                        // Ignore parse errors on partial chunks
                    }
                }
            }
        }
    }
}
