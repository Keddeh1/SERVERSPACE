package com.example

import kotlin.math.max

data class EvolutionReport(
    val healthIndex: Double,
    val interruptFrequencyDelta: Long,
    val memoryAlignmentScore: Double,
    val cpuEfficiencyGrowth: Double,
    val rawTelemetry: HardwareTelemetry,
    val reportString: String
)

class EvolutionReportGenerator(private val hardwareBridge: HardwareBridge) {
    private var baselineTelemetry: HardwareTelemetry? = null
    
    fun captureBaseline(forceReset: Boolean = false) {
        if (baselineTelemetry == null || forceReset) {
            baselineTelemetry = hardwareBridge.fetchRealTimeTelemetry()
        }
    }
    
    fun generateReport(): EvolutionReport {
        val current = hardwareBridge.fetchRealTimeTelemetry()
        val baseline = baselineTelemetry ?: current
        
        // Compute Deltas
        val interruptDelta = current.totalInterrupts - baseline.totalInterrupts
        
        // Memory Lane Alignment (Available / Total) * 100
        val memoryAlignment = if (current.memTotalKb > 0) {
            (current.memFreeKb.toDouble() / current.memTotalKb.toDouble()) * 100.0
        } else 0.0
        
        // CPU Efficiency
        val baselineCpuActive = baseline.cpuTotalTime - baseline.cpuIdleTime
        val currentCpuActive = current.cpuTotalTime - current.cpuIdleTime
        
        val activeDelta = currentCpuActive - baselineCpuActive
        val totalDelta = current.cpuTotalTime - baseline.cpuTotalTime
        
        val cpuLoad = if (totalDelta > 0) (activeDelta.toDouble() / totalDelta.toDouble()) else 0.0
        val cpuEfficiencyGrowth = 100.0 - (cpuLoad * 100.0) // Higher is better (more idle/efficient)

        // Health Index (composite score out of 100)
        // Penalize high interrupt frequency, reward memory alignment and cpu efficiency
        val interruptPenalty = if (interruptDelta > 10000) 10.0 else (interruptDelta / 1000.0)
        val healthIndex = max(0.0, (memoryAlignment * 0.4) + (cpuEfficiencyGrowth * 0.6) - interruptPenalty)
        
        val sb = StringBuilder()
        sb.append("=== BRAINK KERNEL EVOLUTION REPORT ===\n")
        sb.append("Diagnostic & Repair Automation Module\n\n")
        sb.append("[+] Health Index: ${String.format("%.2f", healthIndex)} / 100.0\n")
        sb.append("  - Memory Lane Alignment: ${String.format("%.2f", memoryAlignment)}%\n")
        sb.append("  - BIOS-Level Interrupts (Delta): $interruptDelta\n")
        sb.append("  - CPU Efficiency Growth: ${String.format("%.2f", cpuEfficiencyGrowth)}%\n")
        sb.append("\n[RAW TELEMETRY SNAPSHOT]\n")
        sb.append("  - MemTotal: ${current.memTotalKb} kB\n")
        sb.append("  - MemAvailable: ${current.memFreeKb} kB\n")
        sb.append("  - Total CPU Ticks: ${current.cpuTotalTime}\n")
        
        // Update baseline for continuous evolution
        baselineTelemetry = current
        
        return EvolutionReport(
            healthIndex = healthIndex,
            interruptFrequencyDelta = interruptDelta,
            memoryAlignmentScore = memoryAlignment,
            cpuEfficiencyGrowth = cpuEfficiencyGrowth,
            rawTelemetry = current,
            reportString = sb.toString()
        )
    }
}
