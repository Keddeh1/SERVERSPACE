package com.example

import android.content.Context
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.DiagnosticReceipt
import com.example.data.ProvenanceType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class DiagnosticRepository private constructor(context: Context) {
    private val db = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java, "kex-database"
    ).build()

    private val dao = db.diagnosticReceiptDao()

    val allReceipts: Flow<List<DiagnosticReceipt>> = dao.getAllReceipts()

    private val _uptime = MutableStateFlow(0L)
    val uptime = _uptime.asStateFlow()

    private val _memory = MutableStateFlow(0L)
    val memory = _memory.asStateFlow()

    private val _uptimeHistory = MutableStateFlow(List(20) { 0f })
    val uptimeHistory = _uptimeHistory.asStateFlow()

    private val _memoryHistory = MutableStateFlow(List(20) { 0f })
    val memoryHistory = _memoryHistory.asStateFlow()

    suspend fun recordDiagnostic(uptime: Long, memory: Long, type: ProvenanceType) {
        _uptime.value = uptime
        _memory.value = memory
        
        _uptimeHistory.value = (_uptimeHistory.value.drop(1) + (uptime / 60000f))
        _memoryHistory.value = (_memoryHistory.value.drop(1) + (memory / (1024f * 1024f)))

        val receipt = DiagnosticReceipt(
            taskId = "SYSTEM_DIAGNOSTIC",
            resultData = "Uptime: $uptime, Memory: $memory",
            provenanceId = type
        )
        dao.insertReceipt(receipt)
    }

    suspend fun runGateEvaluation(context: Context): GateMatrixReport {
        return KexGateMatrix.evaluate(context, db)
    }

    suspend fun runGovernanceEvaluation(context: Context): WeaponizedGovernanceReport {
        return KexWeaponizedGovernance.executeFullGovernanceAudit(context, db)
    }

    suspend fun recordGovernanceAction(actionName: String, payload: org.json.JSONObject): DiagnosticReceipt {
        return KexGovernanceFunctions.recordGovernanceReceiptInRoom(db, actionName, payload)
    }

    companion object {
        @Volatile
        private var INSTANCE: DiagnosticRepository? = null

        fun getInstance(context: Context): DiagnosticRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = DiagnosticRepository(context)
                INSTANCE = instance
                instance
            }
        }
    }
}
