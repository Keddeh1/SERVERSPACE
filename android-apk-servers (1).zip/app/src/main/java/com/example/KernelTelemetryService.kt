package com.example

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class KernelTelemetryService(private val runtime: BrainkRuntime, private val repository: DiagnosticRepository) {
    private val _telemetryState = MutableStateFlow(BrainkTelemetryState())
    val telemetryState = _telemetryState.asStateFlow()

    private var telemetryJob: Job? = null
    private var isThoughtActive = false
    private var currentThought = "IDLE (Listening)"
    private var serverUptimeMillis = 0L
    private var memoryUsageBytes = 0L
    private var uptimeHistory = List(20) { 0f }
    private var memoryHistory = List(20) { 0f }

    fun updateServerMetrics(uptime: Long, memory: Long) {
        serverUptimeMillis = uptime
        memoryUsageBytes = memory
    }

    fun start(scope: CoroutineScope) {
        if (telemetryJob != null) return
        telemetryJob = scope.launch(Dispatchers.Default) {
            // Collect metrics from repository
            launch { repository.uptime.collect { serverUptimeMillis = it } }
            launch { repository.memory.collect { memoryUsageBytes = it } }
            launch { repository.uptimeHistory.collect { uptimeHistory = it } }
            launch { repository.memoryHistory.collect { memoryHistory = it } }

            while (isActive) {
                // Update metrics directly from the BRAINK runtime
                val openIrqs = runtime.obligationLedger.count { it["status"] == "OPEN" }
                
                // Determine thought process state
                if (openIrqs > 0 && !isThoughtActive) {
                    currentThought = "RESOLVING OBLIGATIONS ($openIrqs)..."
                } else if (openIrqs == 0 && !isThoughtActive) {
                    currentThought = "IDLE (Listening)"
                }

                _telemetryState.value = BrainkTelemetryState(
                    bootState = runtime.bootState,
                    pllLock = runtime.pllLock,
                    triStateHiz = runtime.triStateHiz,
                    wpLineActive = runtime.wpLineActive,
                    laneMath = runtime.lanes["MATH"] ?: 0L,
                    laneLedger = runtime.lanes["LEDGER"] ?: 0L,
                    laneCode = runtime.lanes["CODE"] ?: 0L,
                    activeSkills = runtime.skills.keys.toList(),
                    openIrqs = openIrqs,
                    thoughtProcess = currentThought,
                    serverUptimeMillis = serverUptimeMillis,
                    memoryUsageBytes = memoryUsageBytes,
                    uptimeHistory = uptimeHistory,
                    memoryHistory = memoryHistory
                )
                delay(100) // 100ms refresh rate for real-time fidelity
            }
        }
    }

    // Allows UI or other systems to override the active thought process
    fun setThoughtProcess(thought: String, active: Boolean = true) {
        currentThought = thought
        isThoughtActive = active
    }

    fun stop() {
        telemetryJob?.cancel()
        telemetryJob = null
    }
}
