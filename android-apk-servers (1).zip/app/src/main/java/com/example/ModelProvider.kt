package com.example

import kotlinx.coroutines.flow.Flow

data class ModelRequest(
    val history: List<ChatMessage>,
    val systemInstruction: String,
    val context: String = ""
)

interface ModelProvider {
    val name: String
    suspend fun generateStream(request: ModelRequest): Flow<String>
}
