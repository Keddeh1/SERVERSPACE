package com.example

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive

class OpenSourceProvider(
    private val baseUrl: String,
    private val apiKey: String,
    private val modelName: String
) : ModelProvider {
    override val name: String = "Open Source ($modelName)"

    private val client = OpenSourceClient(baseUrl)

    override suspend fun generateStream(request: ModelRequest): Flow<String> = flow {
        val messages = mutableListOf<OpenAiMessage>()
        
        // Add system instruction
        val fullInstruction = request.systemInstruction + 
            if (request.context.isNotEmpty()) "\n\n[HOST CODEBASE CONTEXT]\n${request.context}" else ""
        messages.add(OpenAiMessage(role = "system", content = fullInstruction))
        
        // Add history
        request.history.forEach { msg ->
            messages.add(OpenAiMessage(
                role = if (msg.isFromUser) "user" else "assistant",
                content = msg.text
            ))
        }

        val openAiRequest = OpenAiRequest(
            model = modelName,
            messages = messages,
            stream = true
        )

        val response = client.service.generateChatStream("Bearer $apiKey", openAiRequest)
        
        response.byteStream().bufferedReader().use { reader ->
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                if (line!!.startsWith("data: ")) {
                    val jsonStr = line!!.substring(6).trim()
                    if (jsonStr == "[DONE]") continue
                    try {
                        val chunk = Json.parseToJsonElement(jsonStr).jsonObject
                        val delta = chunk["choices"]?.jsonArray
                            ?.getOrNull(0)?.jsonObject
                            ?.get("delta")?.jsonObject
                        
                        val content = delta?.get("content")?.jsonPrimitive?.content ?: ""
                        
                        if (content.isNotEmpty()) {
                            emit(content)
                        }
                    } catch (e: Exception) {
                        // Ignore parse errors on partial chunks
                    }
                }
            }
        }
    }
}
