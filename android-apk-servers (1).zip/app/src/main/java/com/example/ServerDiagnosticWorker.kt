package com.example

import android.content.Context
import android.os.SystemClock
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class ServerDiagnosticWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val uptime = SystemClock.elapsedRealtime()
        val memory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()
        DiagnosticRepository.getInstance(applicationContext).recordDiagnostic(uptime, memory, com.example.data.ProvenanceType.EMPIRICALLY_VERIFIED)
        return Result.success()
    }
}
