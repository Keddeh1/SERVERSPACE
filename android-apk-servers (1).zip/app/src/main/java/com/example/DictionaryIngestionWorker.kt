package com.example

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.BufferedReader
import java.io.InputStreamReader

class DictionaryIngestionWorker(
    context: Context,
    workerParams: WorkerParameters
) : Worker(context, workerParams) {

    override fun doWork(): Result {
        val trie = Trie()
        return try {
            applicationContext.assets.open("dictionary.txt").use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).use { reader ->
                    reader.forEachLine { word ->
                        if (word.isNotBlank()) {
                            trie.insert(word.trim())
                        }
                    }
                }
            }
            // Logic to expose the trie to BRAINK runtime
            // For now, assume a shared singleton or service.
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
