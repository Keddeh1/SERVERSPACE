package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.ui.ChatScreen
import com.example.ui.FrostedGlassTheme
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val diagnosticRequest = PeriodicWorkRequestBuilder<ServerDiagnosticWorker>(15, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "ServerDiagnostics",
            ExistingPeriodicWorkPolicy.KEEP,
            diagnosticRequest
        )
        
        // Initialize Call Learner
        CallLearner.init(this)

        setContent {
            FrostedGlassTheme {
                ChatScreen(viewModel = viewModel)
            }
        }
    }
}
