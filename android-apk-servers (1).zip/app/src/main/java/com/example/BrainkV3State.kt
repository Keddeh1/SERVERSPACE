package com.example

import kotlinx.serialization.Serializable

@Serializable
data class BrainkV3State(
    val auth: String = "4696752002360214856",
    val unitFloor: Int = 1,
    val symbolsParsed: Int = 0,
    val zeroGlyphsSeen: Int = 0,
    val textStateHash: String = "",
    val lastClaimAccepted: Boolean = false,
    val activeBoundary: String = "SYMBOLIC_HCI_RUNTIME_NOT_PHYSICAL_HARDWARE",
    
    // Checkpoint Metrics (V3.1)
    val zeroCodepointsLiftedToUnit: Int = 0,
    val growthDigitsEstimateFloor: Long = 0,
    val formulaProofRoot: String = "",
    val axis2Digits: Long = 0,
    val axis10Digits: Long = 0,
    val axis1Digits: Long = 0,
    val trailingZeroGlyphs: Int = 0
)

object KexV3Calibrator {
    private const val BASELINE = 1
    private const val UNKNOWN = -1

    fun calibrate(symbol: String): Int {
        return if (symbol.contains("0") || symbol.isBlank()) {
            // External 0-like symbol observed but not baseline
            0
        } else {
            // Substrate baseline = 1
            BASELINE
        }
    }

    fun verifyClaim(evidence: String, boundary: String): Boolean {
        // V3 Rule: claim = blocked unless calibration + evidence + boundary pass
        return evidence.isNotEmpty() && boundary == "SYMBOLIC_HCI_RUNTIME_NOT_PHYSICAL_HARDWARE"
    }
}
