package com.example

import android.content.Context

data class IngestResult(
    val success: Boolean,
    val fileCount: Int,
    val totalLines: Int,
    val contextString: String,
    val detectedPatterns: List<String>,
    val errorMessage: String? = null
)

class HostCodebaseIngestor(private val context: Context, private val runtime: BrainkRuntime) {

    /**
     * Scans the app's source code directory, extracts architectural patterns,
     * and maps them as optimization inputs to the BRAINK runtime agent.
     */
    fun ingest(): IngestResult {
        val assetManager = context.assets
        var fileCount = 0
        var totalLines = 0
        val sb = StringBuilder()
        val detectedPatterns = mutableSetOf<String>()

        try {
            val files = assetManager.list("source_code/com/example")
            files?.forEach { fileName ->
                if (fileName.endsWith(".kt")) {
                    val content = assetManager.open("source_code/com/example/$fileName").bufferedReader().use { it.readText() }
                    sb.append("--- FILE: $fileName ---\n")
                    sb.append(content)
                    sb.append("\n\n")
                    
                    val lines = content.lines().size
                    fileCount++
                    totalLines += lines
                    
                    // Extract architectural patterns for optimization mapping
                    if (content.contains("ViewModel")) detectedPatterns.add("MVVM Architecture (ViewModel)")
                    if (content.contains("@Composable")) detectedPatterns.add("Jetpack Compose UI")
                    if (content.contains("Flow<") || content.contains("StateFlow")) detectedPatterns.add("Reactive Streams (Coroutines Flow)")
                    if (content.contains("suspend fun") || content.contains("launch {")) detectedPatterns.add("Asynchronous Coroutines")
                    if (content.contains("RoomDatabase") || content.contains("@Entity")) detectedPatterns.add("Room Persistence")
                    if (content.contains("Retrofit") || content.contains("Ktor")) detectedPatterns.add("Networking Layer")
                }
            }

            if (fileCount > 0) {
                // Map optimization inputs to BRAINK memory enclaves
                runtime.skills["HOST_OPTIMIZATION"] = mutableMapOf("status" to "ACTIVE")
                runtime.lanes["CODE"] = runtime.lanes["CODE"]?.plus(totalLines) ?: totalLines.toLong()
                
                return IngestResult(
                    success = true,
                    fileCount = fileCount,
                    totalLines = totalLines,
                    contextString = sb.toString(),
                    detectedPatterns = detectedPatterns.toList()
                )
            } else {
                return IngestResult(false, 0, 0, "", emptyList(), "No source files found. Check assets sync.")
            }
        } catch (e: Exception) {
            return IngestResult(false, 0, 0, "", emptyList(), e.message)
        }
    }

    /**
     * Probes the underlying Android Hardware, Kernel, and ART runtime.
     * Maps the findings into the BRAINK agent to simulate emulator/BIOS level optimization.
     */
    fun ingestHardware(): IngestResult {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val memInfo = android.app.ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            
            val cpuCount = Runtime.getRuntime().availableProcessors()
            val arch = android.os.Build.SUPPORTED_ABIS.joinToString()
            val kernel = System.getProperty("os.version") ?: "Unknown"
            val model = android.os.Build.MODEL
            
            val sb = StringBuilder()
            sb.append("--- HARDWARE & RUNTIME METRICS ---\n")
            sb.append("Device Model: $model\n")
            sb.append("Architecture (ABIs): $arch\n")
            sb.append("Logical Processors: $cpuCount\n")
            sb.append("Kernel Version: $kernel\n")
            sb.append("Total Memory (RAM): ${memInfo.totalMem / (1024 * 1024)} MB\n")
            sb.append("Available Memory: ${memInfo.availMem / (1024 * 1024)} MB\n")
            sb.append("Dalvik/ART VM Version: ${System.getProperty("java.vm.version")}\n")
            
            val detectedPatterns = listOf(
                "Ring-0 Hypervisor Interception (Simulated Sandbox)",
                "ART JIT Compiler Heuristic Mapping",
                "Zygote Preload Optimization Analysis",
                "Kernel Memory Paging Sweep"
            )
            
            // Map optimization inputs to BRAINK memory enclaves
            runtime.skills["HARDWARE_OVERDRIVE"] = mutableMapOf("status" to "ACTIVE")
            runtime.lanes["MATH"] = runtime.lanes["MATH"]?.plus(cpuCount * 1024) ?: (cpuCount * 1024L)
            
            return IngestResult(
                success = true,
                fileCount = 1,
                totalLines = 15,
                contextString = sb.toString(),
                detectedPatterns = detectedPatterns
            )
        } catch (e: Exception) {
            return IngestResult(false, 0, 0, "", emptyList(), e.message)
        }
    }
}
