package com.example

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

class SelfRepairDaemon(
    private val runtime: BrainkRuntime,
    private val reportGenerator: EvolutionReportGenerator
) {
    private val _repairEvents = MutableSharedFlow<String>()
    val repairEvents = _repairEvents.asSharedFlow()

    private var monitorJob: Job? = null
    
    // Configurable thresholds for the automaton
    private val HEALTH_CRITICAL_THRESHOLD = 50.0
    private val INTERRUPT_VARIANCE_SPIKE = 50000L

    fun startMonitoring(scope: CoroutineScope) {
        if (monitorJob != null) return
        monitorJob = scope.launch(Dispatchers.Default) {
            while(isActive) {
                delay(15000) // Autonomous background check every 15 seconds
                
                val report = reportGenerator.generateReport()
                
                // Detect variance in the runtime
                if (report.healthIndex < HEALTH_CRITICAL_THRESHOLD || report.interruptFrequencyDelta > INTERRUPT_VARIANCE_SPIKE) {
                    forceAlignment(report)
                }
            }
        }
    }
    
    fun forceAlignment(report: EvolutionReport? = null) {
        // 1. Force Memory Lane Alignment (Reset/Stabilize)
        val currentMath = runtime.lanes["MATH"] ?: 1024L
        val currentCode = runtime.lanes["CODE"] ?: 1024L
        
        // Re-align lanes to stable harmonics, preventing overflow/corruption
        runtime.lanes["MATH"] = currentMath - (currentMath % 256)
        runtime.lanes["CODE"] = currentCode - (currentCode % 256)
        
        // 2. Clear volatile ledger obligations causing drift
        runtime.obligationLedger.removeAll { it["status"] == "OPEN" }
        
        // 3. Re-calibrate hardware baseline
        reportGenerator.captureBaseline(forceReset = true)
        
        // 4. Dispatch System Alert
        val reason = report?.let {
            "Variance trigger: Health [${String.format("%.2f", it.healthIndex)}] | Interrupts [${it.interruptFrequencyDelta}]"
        } ?: "Manual Override"

        val alert = """
            [!] SELF-REPAIR AUTOMATON TRIGGERED
            $reason
            - Memory Lane Alignment Forced.
            - Volatile Obligations Purged.
            - BIOS-Level Telemetry Baseline Recalibrated.
            BRAINK runtime variance resolved.
        """.trimIndent()
        
        // Fire-and-forget emit for the UI to catch
        CoroutineScope(Dispatchers.Main).launch {
            _repairEvents.emit(alert)
        }
    }

    fun stopMonitoring() {
        monitorJob?.cancel()
        monitorJob = null
    }
}
