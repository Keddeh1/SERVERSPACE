package com.example.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromProvenanceType(value: ProvenanceType): String {
        return value.name
    }

    @TypeConverter
    fun toProvenanceType(value: String): ProvenanceType {
        return ProvenanceType.valueOf(value)
    }
}
