package com.example.data

enum class ProvenanceType {
    EMPIRICALLY_VERIFIED,
    DECLARED
}
