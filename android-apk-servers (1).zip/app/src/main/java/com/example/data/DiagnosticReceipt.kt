package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "diagnostic_receipts")
data class DiagnosticReceipt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: String,
    val resultData: String,
    val provenanceId: ProvenanceType
)
