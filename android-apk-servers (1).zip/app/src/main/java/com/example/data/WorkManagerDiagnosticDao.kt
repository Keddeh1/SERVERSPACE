package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkManagerDiagnosticDao {
    @Query("SELECT * FROM work_manager_diagnostic_receipts ORDER BY timestamp DESC")
    fun getAllReceipts(): Flow<List<WorkManagerDiagnosticReceipt>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceipt(receipt: WorkManagerDiagnosticReceipt)
}
