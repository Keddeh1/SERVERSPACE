package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "work_manager_diagnostic_receipts")
data class WorkManagerDiagnosticReceipt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val diagnosticPayload: String,
    val timestamp: Long = System.currentTimeMillis(),
    val sourceProvenanceIdentifier: String
)
