package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DiagnosticReceiptDao {
    @Query("SELECT * FROM diagnostic_receipts ORDER BY id DESC")
    fun getAllReceipts(): Flow<List<DiagnosticReceipt>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceipt(receipt: DiagnosticReceipt)
}
