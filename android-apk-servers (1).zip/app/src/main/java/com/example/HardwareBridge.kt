package com.example

import java.io.File
import android.util.Log

data class HardwareTelemetry(
    val memTotalKb: Long,
    val memFreeKb: Long,
    val totalInterrupts: Long,
    val cpuIdleTime: Long,
    val cpuTotalTime: Long
)

class HardwareBridge {
    // Interfacing directly with low-level Android system files (Bypassing JNI for sandboxed stability)
    fun fetchRealTimeTelemetry(): HardwareTelemetry {
        var memTotal = 0L
        var memFree = 0L
        try {
            val memInfo = File("/proc/meminfo").readLines()
            memTotal = memInfo.find { it.startsWith("MemTotal:") }?.substringAfter(":")?.substringBefore("kB")?.trim()?.toLongOrNull() ?: 0L
            memFree = memInfo.find { it.startsWith("MemAvailable:") }?.substringAfter(":")?.substringBefore("kB")?.trim()?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            Log.e("HardwareBridge", "Failed to read /proc/meminfo", e)
        }

        var totalInterrupts = 0L
        var cpuIdle = 0L
        var cpuTotal = 0L
        try {
            val statInfo = File("/proc/stat").readLines()
            totalInterrupts = statInfo.find { it.startsWith("intr ") }?.split(" ")?.getOrNull(1)?.toLongOrNull() ?: 0L
            
            val cpuLine = statInfo.find { it.startsWith("cpu ") }
            if (cpuLine != null) {
                val parts = cpuLine.split("\\s+".toRegex()).drop(1)
                if (parts.size >= 4) {
                    val user = parts[0].toLongOrNull() ?: 0L
                    val nice = parts[1].toLongOrNull() ?: 0L
                    val system = parts[2].toLongOrNull() ?: 0L
                    val idle = parts[3].toLongOrNull() ?: 0L
                    cpuIdle = idle
                    cpuTotal = user + nice + system + idle
                }
            }
        } catch (e: Exception) {
            Log.e("HardwareBridge", "Failed to read /proc/stat", e)
        }

        return HardwareTelemetry(memTotal, memFree, totalInterrupts, cpuIdle, cpuTotal)
    }
}
