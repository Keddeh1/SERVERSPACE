package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.ProvenanceType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class KexMechanicalVerificationTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `KexSeedAuthority executes deterministic mathematical projections`() {
        val receipt = KexSeedAuthority.verify(4696753037434160968L)

        // 1. Verify byte-level projections
        assertEquals("A.8", receipt.asciiPrefix)
        assertEquals('H', receipt.anchorChar)
        assertEquals(7, receipt.bypassIndex)
        assertEquals(listOf(65, 46, 56, 0, 202, 0, 7, 72), receipt.rawBytes)

        // 2. Verify IEEE 754 float decoding
        assertEquals(990208.394531467, receipt.float64Value, 0.000001)

        // 3. Verify deterministic register lanes
        assertEquals(8L, receipt.laneMath)
        assertEquals(1L, receipt.laneLedger)
        assertEquals(99L, receipt.laneCode)

        // 4. Verify Logarithmic VFD Strand Length
        assertEquals(106977, receipt.vfdStrandLength)

        // 5. Verify cryptographic SHA-256 digest
        assertNotNull(receipt.sha256Digest)
        assertEquals(64, receipt.sha256Digest.length)

        // 6. Overall validity
        assertTrue(receipt.isValid)
    }

    @Test
    fun `KexGateMatrix executes G0 to G8 and enforces Fail-Closed Governance`() = runBlocking {
        val report = KexGateMatrix.evaluate(context, database)

        // The matrix should pass completely under nominal conditions
        assertTrue("Gate matrix should pass all gates", report.passed)
        assertEquals(9, report.results.size)

        // Verify every individual gate
        report.results.forEach { gate ->
            assertEquals("Gate ${gate.gateId} (${gate.name}) should pass", GateStatus.PASSED, gate.status)
            assertTrue("Gate ${gate.gateId} details should not be empty", gate.details.isNotEmpty())
        }

        // Verify that G8 persisted an EMPIRICALLY_VERIFIED receipt into Room
        val receipts = database.diagnosticReceiptDao().getAllReceipts().first()
        assertTrue("Database should contain at least one receipt", receipts.isNotEmpty())
        val latestReceipt = receipts.first()
        assertEquals(ProvenanceType.EMPIRICALLY_VERIFIED, latestReceipt.provenanceId)
        assertTrue(latestReceipt.resultData.contains("EMPIRICALLY_VERIFIED"))
    }

    @Test
    fun `KexGateMatrix fails closed when precursor gate invariant is violated`() = runBlocking {
        // Pass a corrupted seed (0L) to test that G0 fails and triggers fail-closed governance
        val corruptedSeed = 0L
        val report = KexGateMatrix.evaluate(context, database, seedDecimal = corruptedSeed)

        assertFalse("Matrix should fail when seed validation fails", report.passed)
        val g0 = report.results.find { it.gateId == "G0" }
        assertNotNull(g0)
        assertEquals(GateStatus.FAILED, g0!!.status)

        // Precursor failed at G0 -> G1..G6 and G8 must be BLOCKED
        val g1 = report.results.find { it.gateId == "G1" }
        val g4 = report.results.find { it.gateId == "G4" }
        val g8 = report.results.find { it.gateId == "G8" }
        assertEquals(GateStatus.BLOCKED, g1?.status)
        assertEquals(GateStatus.BLOCKED, g4?.status)
        assertEquals(GateStatus.BLOCKED, g8?.status)

        // Fail-Closed Governance (G7) must record failure
        val g7 = report.results.find { it.gateId == "G7" }
        assertEquals(GateStatus.FAILED, g7?.status)
    }
}
