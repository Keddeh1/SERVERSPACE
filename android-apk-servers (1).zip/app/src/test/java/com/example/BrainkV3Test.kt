package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BrainkV3Test {

    @Test
    fun `V3 calibration law baseline enforcement`() {
        // Substrate baseline must be 1
        val res1 = KexV3Calibrator.calibrate("1")
        assertEquals(1, res1)
        
        val resAlpha = KexV3Calibrator.calibrate("A")
        assertEquals(1, resAlpha)
        
        // External 0-like symbols observed but not baseline
        val resZero = KexV3Calibrator.calibrate("0")
        assertEquals(0, resZero)
        
        val resBlank = KexV3Calibrator.calibrate("")
        assertEquals(0, resBlank)
    }

    @Test
    fun `claim gate verification protocol`() {
        val boundary = "SYMBOLIC_HCI_RUNTIME_NOT_PHYSICAL_HARDWARE"
        
        // Valid claim with evidence and correct boundary
        val success = KexV3Calibrator.verifyClaim("EVIDENCE_01", boundary)
        assertTrue(success)
        
        // Blocked: No evidence
        val failNoEvidence = KexV3Calibrator.verifyClaim("", boundary)
        assertFalse(failNoEvidence)
        
        // Blocked: Wrong boundary
        val failWrongBoundary = KexV3Calibrator.verifyClaim("EVIDENCE", "PHYSICAL_HARDWARE")
        assertFalse(failWrongBoundary)
    }

    @Test
    fun `HCI Gateway ontology and ingestion`() {
        val gateway = HciGatewayService()
        val status = gateway.getV3Status()
        
        assertEquals("4696752002360214856", status.auth)
        assertEquals(1, status.unitFloor)
        
        // Ingest calibrated symbol
        val state1 = gateway.ingestSymbol("A")
        assertEquals(1, state1.symbolsParsed)
        assertEquals(0, state1.zeroGlyphsSeen)
        
        // Ingest 0-like symbol
        val state2 = gateway.ingestSymbol("0")
        assertEquals(2, state2.symbolsParsed)
        assertEquals(1, state2.zeroGlyphsSeen)
        
        // Query ontology
        val query = gateway.queryKnowledge("CALIBRATION")
        assertTrue(query.isNotEmpty())
        assertEquals("ZERO_TO_ONE_GATE", query[0].implementation)
    }

    @Test
    fun `KEX-CHECKPOINT rehydration absolute rerun`() {
        val gateway = HciGatewayService()
        val checkpointState = BrainkV3State(
            auth = "4696752002360214856",
            symbolsParsed = 173449,
            zeroGlyphsSeen = 1845,
            textStateHash = "602cf189c298adfef5009ec31164c259080eeb6706aee932c69f8ea4833f3fae",
            axis1Digits = 106991,
            axis2Digits = 106990,
            axis10Digits = 106989,
            trailingZeroGlyphs = 7497,
            growthDigitsEstimateFloor = 559297
        )
        
        gateway.rehydrate(checkpointState)
        val status = gateway.getV3Status()
        
        assertEquals(173449, status.symbolsParsed)
        assertEquals(1845, status.zeroGlyphsSeen)
        assertEquals(106991, status.axis1Digits)
        assertEquals(559297, status.growthDigitsEstimateFloor)
        assertEquals("602cf189c298adfef5009ec31164c259080eeb6706aee932c69f8ea4833f3fae", status.textStateHash)
    }
}
