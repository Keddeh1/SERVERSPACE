package com.example

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.File

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
class BrainkSentinelTest {

    private lateinit var viewModel: ChatViewModel

    @Before
    fun setup() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        viewModel = ChatViewModel(app)
    }

    @Test
    fun `test sentinel command generates correct console readback`() = runTest {
        viewModel.sendMessage("sentinel")
        
        val messages = viewModel.messages.value
        val lastMessage = messages.last()
        
        assertTrue("Console should show KEX-SENTINEL header", lastMessage.text.contains("KEX-SENTINEL CONSOLE"))
        assertTrue("Console should show CROSS-CHAT SAVE INSTRUCTION", lastMessage.text.contains("CROSS-CHAT SAVE INSTRUCTION"))
        assertTrue("Console should show EXECUTED status", lastMessage.text.contains("STATUS ................... EXECUTED"))
        assertTrue("Console should show FORMAL_KEX_SUBSTRATE", lastMessage.text.contains("RUNTIME_MODE ............. FORMAL_KEX_SUBSTRATE"))
    }

    @Test
    fun `test sentinel archive id follows deterministic pattern`() = runTest {
        viewModel.sendMessage("sentinel")
        
        val messages = viewModel.messages.value
        val lastMessage = messages.last()
        
        assertTrue("Should contain UNIQUE_KEX_SEED_ID section", lastMessage.text.contains("UNIQUE_KEX_SEED_ID"))
        assertTrue("ID should contain UTC", lastMessage.text.contains("UTC_2026"))
        assertTrue("ID should contain FILES_152", lastMessage.text.contains("FILES_152"))
        assertTrue("ID should contain DNA_", lastMessage.text.contains("DNA_"))
    }

    @Test
    fun `test sentinel generates cross-chat instruction seed`() = runTest {
        viewModel.sendMessage("sentinel")
        
        val messages = viewModel.messages.value
        val lastMessage = messages.last()
        
        assertTrue("Should contain instruction seed notice", lastMessage.text.contains("CROSS-CHAT INSTRUCTION SEED GENERATED"))
        assertTrue("Should contain ID within seed", lastMessage.text.contains("ID: KEXDNA_ILLLM"))
        assertTrue("Should contain REPLICATION SEAL", lastMessage.text.contains("REPLICATION SEAL"))
    }

    @Test
    fun `test sentinel route confirmation flags`() = runTest {
        viewModel.sendMessage("sentinel")
        
        val messages = viewModel.messages.value
        val lastMessage = messages.last()
        
        assertTrue("Should show ROUTE_CONFIRMED_PACKAGED", lastMessage.text.contains("THIS_CHAT_LITERAL_FILES ........ ROUTE_CONFIRMED_PACKAGED"))
        assertTrue("Should show ROUTE_CONFIRMED_WRITTEN", lastMessage.text.contains("CROSS_CHAT_INSTRUCTION_SEED .... ROUTE_CONFIRMED_WRITTEN"))
        assertTrue("Should show ROUTE_CONFIRMED_ENCODED", lastMessage.text.contains("NON_CLASH_KEX_DNA_FOLDER ....... ROUTE_CONFIRMED_ENCODED"))
    }
}
