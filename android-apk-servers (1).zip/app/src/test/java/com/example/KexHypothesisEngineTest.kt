package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class KexHypothesisEngineTest {

    @Test
    fun `test all 8 hypotheses pass with zero failures`() {
        val results = KexHypothesisEngine.runAllHypotheses()
        assertEquals(8, results.size)
        
        results.forEach { h ->
            assertTrue("Hypothesis ${h.hypothesisId} (${h.name}) should pass", h.passed)
            assertTrue("Target claim should not be empty", h.targetClaim.isNotEmpty())
            assertTrue("Measured metric should not be empty", h.measuredMetric.isNotEmpty())
        }
    }

    @Test
    fun `test 4-plane substrate state is coherent`() {
        val state = KexHypothesisEngine.sampleFourPlaneState()
        assertTrue(state.isCoherent)
        assertTrue(state.displayPlane.contains("Observer"))
        assertTrue(state.osEnginePlane.contains("Relational"))
        assertTrue(state.memoryPlane.contains("1-Origin"))
        assertTrue(state.driverVfsPlane.contains("Resolver"))
    }
}
