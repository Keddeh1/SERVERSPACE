package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class KexInvariantTest {

    @Test
    fun `test P01 Zeroless Continuity Law - Active state maintains lineage`() {
        val value = "test_payload"
        val lineageHash = "0xdeadbeef"
        val state = KexState.Active(value, lineageHash)
        
        assertTrue(state is KexState.Active)
        assertEquals(value, (state as KexState.Active).value)
        assertEquals(lineageHash, state.lineageHash)
    }

    @Test
    fun `test P01 Zeroless Continuity Law - Absent state maintains lineage`() {
        val predecessorHash = "0xfeedface"
        val state = KexState.Absent(predecessorHash)
        
        assertTrue(state is KexState.Absent)
        assertEquals(predecessorHash, (state as KexState.Absent).predecessorHash)
    }

    @Test
    fun `test SIGNAL and SIGNALED distinction`() {
        val resource = KexResource.Literal(
            function = "projection/open",
            forms = listOf("void"),
            minPayloadSize = 0
        )
        
        val invocation = KexInvocation(
            signal = resource,
            invocationId = "E2841",
            timestamp = System.currentTimeMillis(),
            context = emptyMap(),
            authority = "KEX_TRUST_ROOT"
        )
        
        assertEquals("projection/open", invocation.signal.function)
        assertEquals("E2841", invocation.invocationId)
        assertEquals("KEX_TRUST_ROOT", invocation.authority)
    }
}
