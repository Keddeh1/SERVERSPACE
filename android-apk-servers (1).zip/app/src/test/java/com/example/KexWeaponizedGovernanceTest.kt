package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.ProvenanceType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class KexWeaponizedGovernanceTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `test ARB evaluation enforces No Architecture No Funding rule`() {
        val proposals = KexWeaponizedGovernance.getStandardProjectProposals()
        val noBlueprintProposal = proposals.first { it.projectId == "PROJ-102" }
        assertFalse("Project 102 should have no blueprint submission", noBlueprintProposal.hasBlueprintSubmission)

        val receipts = KexWeaponizedGovernance.evaluateFundingProposals(listOf(noBlueprintProposal))
        assertEquals(1, receipts.size)
        val receipt = receipts.first()

        assertEquals(ArbReviewStatus.PENDING_BLUEPRINT_SUBMISSION, receipt.reviewStatus)
        assertEquals(FundingGateVerdict.BLOCKED_NO_BLUEPRINT, receipt.fundingVerdict)
        assertEquals(0.0, receipt.allocatedCapitalUsd, 0.001)
        assertTrue(receipt.justification.contains("No Architecture, No Funding"))
        assertEquals(64, receipt.voucherHash.length)
    }

    @Test
    fun `test ARB evaluation enforces Fail Closed threshold on low alignment`() {
        val proposals = KexWeaponizedGovernance.getStandardProjectProposals()
        val lowAlignmentProposal = proposals.first { it.projectId == "PROJ-103" }
        assertTrue("Project 103 alignment score should be below 80%", lowAlignmentProposal.alignmentScorePercent < 80.0)

        val receipts = KexWeaponizedGovernance.evaluateFundingProposals(listOf(lowAlignmentProposal))
        assertEquals(1, receipts.size)
        val receipt = receipts.first()

        assertEquals(ArbReviewStatus.REJECTED_NON_COMPLIANT, receipt.reviewStatus)
        assertEquals(FundingGateVerdict.DEFUNDED_FAIL_CLOSED, receipt.fundingVerdict)
        assertEquals(0.0, receipt.allocatedCapitalUsd, 0.001)
        assertTrue(receipt.justification.contains("Fail-Closed Governance"))
        assertEquals(64, receipt.voucherHash.length)
    }

    @Test
    fun `test ARB evaluation approves 100 percent aligned blueprints`() {
        val proposals = KexWeaponizedGovernance.getStandardProjectProposals()
        val alignedProposal = proposals.first { it.projectId == "PROJ-101" }
        assertEquals(100.0, alignedProposal.alignmentScorePercent, 0.001)
        assertTrue(alignedProposal.hasBlueprintSubmission)

        val receipts = KexWeaponizedGovernance.evaluateFundingProposals(listOf(alignedProposal))
        assertEquals(1, receipts.size)
        val receipt = receipts.first()

        assertEquals(ArbReviewStatus.APPROVED, receipt.reviewStatus)
        assertEquals(FundingGateVerdict.FUNDED_ALLOCATION_APPROVED, receipt.fundingVerdict)
        assertEquals(1200000.0, receipt.allocatedCapitalUsd, 0.001)
        assertTrue(receipt.justification.contains("ARB APPROVED"))
        assertEquals(64, receipt.voucherHash.length)
    }

    @Test
    fun `test Golden Path blueprints guarantee 100 percent compliance by construction`() {
        val blueprints = KexWeaponizedGovernance.getGoldenPathBlueprints()
        assertEquals(4, blueprints.size)

        blueprints.forEach { gp ->
            assertEquals(100.0, gp.complianceRatePercent, 0.001)
            assertTrue(gp.builtInSecurity.isNotEmpty())
            assertTrue(gp.builtInLogging.isNotEmpty())
            assertTrue(gp.builtInGates.isNotEmpty())
            assertTrue(gp.deploymentScaffoldScript.isNotEmpty())
            assertTrue(gp.starterManifest.isNotEmpty())
        }
    }

    @Test
    fun `test Buy vs Build filter automatically disqualifies non-standard vendor software`() {
        val vendors = KexWeaponizedGovernance.evaluateVendorSoftware()
        assertEquals(4, vendors.size)

        val proprietaryDb = vendors.first { it.productName == "OmniStore DB" }
        assertEquals(ProcurementStatus.AUTOMATICALLY_DISQUALIFIED, proprietaryDb.status)
        assertFalse(proprietaryDb.supportsStandardProtocols)
        assertTrue(proprietaryDb.auditNotes.contains("AUTOMATICALLY DISQUALIFIED"))

        val proprietaryApm = vendors.first { it.productName == "ProprietaryAPM Agent" }
        assertEquals(ProcurementStatus.AUTOMATICALLY_DISQUALIFIED, proprietaryApm.status)
        assertFalse(proprietaryApm.supportsStandardProtocols)

        val standardIdentity = vendors.first { it.productName == "CloudIdentity Enterprise" }
        assertEquals(ProcurementStatus.APPROVED_FOR_PROCUREMENT, standardIdentity.status)
        assertTrue(standardIdentity.supportsStandardProtocols)

        val internalQueue = vendors.first { it.productName == "CustomBroker v4" }
        assertEquals(ProcurementStatus.FLAGGED_FOR_INTERNAL_BUILD, internalQueue.status)
    }

    @Test
    fun `test Portfolio Rationalization identifies redundant tools and calculates licensing savings`() {
        val report = KexWeaponizedGovernance.rationalizePortfolio()
        assertEquals(5, report.totalRedundantToolsIdentified)
        assertTrue("Projected annual savings should be positive", report.projectedAnnualSavingsUsd > 500000.0)
        assertEquals(5, report.items.size)
        assertTrue(report.targetStandardConsolidations.isNotEmpty())
    }

    @Test
    fun `test Systemic Tech Debt scoring quantifies growth blocking risk and ROI`() {
        val report = KexWeaponizedGovernance.auditSystemicTechDebt()
        assertTrue("Debt score should exceed 80", report.totalDebtScore > 80.0)
        assertTrue("Annual maintenance drag should exceed $500k", report.totalAnnualMaintenanceDragUsd > 500000.0)
        assertEquals(3, report.highestRiskBlockers.size)
        assertTrue(report.executiveSummary.contains("CRITICAL BLOCKERS DETECTED"))

        report.highestRiskBlockers.forEach { blocker ->
            assertTrue(blocker.techDebtScore in 1..100)
            assertTrue(blocker.modernizationProposal.isNotEmpty())
            assertTrue(blocker.executiveRoiJustification.isNotEmpty())
        }
    }

    @Test
    fun `test North Star roadmap guides reduce time to market while preserving integrity`() {
        val roadmaps = KexWeaponizedGovernance.generateNorthStarRoadmaps()
        assertEquals(3, roadmaps.size)

        roadmaps.forEach { path ->
            assertTrue(path.estimatedTtmReductionPercent >= 50.0)
            assertTrue(path.architecturalIntegrityPreserved)
            assertTrue(path.fastestScalablePath.isNotEmpty())
            assertTrue(path.goldenPathToLeverage.isNotEmpty())
        }
    }

    @Test
    fun `test full governance audit persists EMPIRICALLY VERIFIED receipt into Room`() = runBlocking {
        val report = KexWeaponizedGovernance.executeFullGovernanceAudit(context, database)

        assertNotNull(report)
        assertEquals(3650000.0, report.totalCapitalGuardedUsd, 0.001)
        assertEquals(1500000.0, report.totalCapitalDefundedUsd, 0.001)
        assertEquals(2150000.0, report.totalCapitalApprovedUsd, 0.001)
        assertTrue(report.totalLicensingSavingsUsd > 0.0)

        val receipts = database.diagnosticReceiptDao().getAllReceipts().first()
        val govReceipt = receipts.firstOrNull { it.taskId.startsWith("GOVERNANCE_GATE_") }
        assertNotNull("Should persist GOVERNANCE_GATE receipt to Room", govReceipt)
        assertEquals(ProvenanceType.EMPIRICALLY_VERIFIED, govReceipt?.provenanceId)
        assertTrue(govReceipt?.resultData?.contains("total_capital_defunded_usd") == true)
        assertTrue(govReceipt?.resultData?.contains("EMPIRICALLY_VERIFIED") == true)
    }

    @Test
    fun `test enforceNoArchitectureNoFunding software function halts capital release`() {
        val receipt = KexGovernanceFunctions.enforceNoArchitectureNoFunding(
            projectId = "PROJ-UNVERIFIED",
            projectName = "Shadow Service",
            requestedBudgetUsd = 450000.0,
            hasBlueprint = false
        )

        assertEquals(FundingGateVerdict.BLOCKED_NO_BLUEPRINT, receipt.fundingVerdict)
        assertEquals(0.0, receipt.allocatedCapitalUsd, 0.001)
        assertTrue(receipt.justification.contains("No Architecture, No Funding"))
        assertEquals(64, receipt.voucherHash.length)
    }

    @Test
    fun `test conveneArbReview and authorizeBudgetRelease software functions`() {
        val alignedStack = listOf(
            TechStackAlignment("Compute", "Kotlin Coroutines", "Kotlin / Coroutines", true),
            TechStackAlignment("RPC", "gRPC", "gRPC / Protobuf", true),
            TechStackAlignment("Persistence", "Room SQLite", "Room SQLite Injective Engine", true)
        )
        val receipt = KexGovernanceFunctions.conveneArbReview(
            projectId = "PROJ-REALTIME",
            projectName = "Settlement Engine",
            requestedBudgetUsd = 800000.0,
            architect = "Lead Architect",
            hasBlueprint = true,
            techStack = alignedStack
        )

        assertEquals(ArbReviewStatus.APPROVED, receipt.reviewStatus)
        assertEquals(FundingGateVerdict.FUNDED_ALLOCATION_APPROVED, receipt.fundingVerdict)
        assertEquals(800000.0, receipt.allocatedCapitalUsd, 0.001)

        val auth = KexGovernanceFunctions.authorizeBudgetRelease(receipt)
        assertTrue(auth.isAuthorized)
        assertEquals(800000.0, auth.authorizedAmountUsd, 0.001)
        assertEquals("BUDGET_RELEASE_AUTHORIZED", auth.status)
        assertEquals(64, auth.signatureDigest.length)
    }

    @Test
    fun `test scaffoldGoldenPath software function writes physical files and computes tree digest`() {
        val testOutputDir = java.io.File(context.filesDir, "test_scaffolds/microservice_test")
        testOutputDir.deleteRecursively()

        val result = KexGovernanceFunctions.scaffoldGoldenPath(
            templateId = "GP-SVC-01",
            serviceName = "billing-dispatcher",
            destinationDir = testOutputDir
        )

        assertEquals("billing-dispatcher", result.serviceName)
        assertEquals(5, result.generatedFiles.size)
        assertTrue(result.totalBytesGenerated > 500)
        assertEquals(64, result.treeDigestSha256.length)
        assertTrue(result.compliancePassed)

        // Verify physical files exist on filesystem
        val appFile = java.io.File(testOutputDir, "src/main/kotlin/com/example/billing-dispatcher/Application.kt")
        assertTrue("Physical Application.kt file must exist", appFile.exists())
        assertTrue(appFile.readText().contains("GateMatrixVerifier"))

        val secFile = java.io.File(testOutputDir, "src/main/kotlin/com/example/billing-dispatcher/SecurityConfig.kt")
        assertTrue("Physical SecurityConfig.kt must exist", secFile.exists())

        // Test template compliance audit
        val audit = KexGovernanceFunctions.verifyTemplateCompliance("GP-SVC-01", testOutputDir.walkTopDown().filter { it.isFile }.toList())
        assertTrue("Audit should pass compliance", audit.isCompliant)
        assertTrue(audit.hasZeroTrustSecurity)
        assertTrue(audit.hasStructuredTelemetry)
        assertTrue(audit.hasGateMatrixVerifier)
    }

    @Test
    fun `test evaluateBuyVsBuildFilter software function rejects non-compliant vendors`() {
        val nonCompliantVendor = VendorEvaluationInput(
            vendorName = "LegacyCloud",
            productName = "ClosedDB",
            category = "Database",
            annualCostUsd = 200000.0,
            supportedProtocols = listOf("CustomProprietaryWire"),
            isOpenStandard = false,
            supportsZeroTrustAuth = false
        )
        val result = KexGovernanceFunctions.evaluateBuyVsBuildFilter(nonCompliantVendor)
        assertEquals(ProcurementStatus.AUTOMATICALLY_DISQUALIFIED, result.status)
        assertFalse(result.supportsStandardProtocols)
        assertTrue(result.auditNotes.contains("AUTOMATICALLY DISQUALIFIED"))
    }

    @Test
    fun `test computeSystemicTechDebtScore and formulateExecutiveModernizationJustification software functions`() {
        val auditInput = LegacyAuditInput(
            systemId = "LEGACY-PAY-01",
            systemName = "Batch Payment Cron",
            annualMaintenanceUsd = 220000.0,
            incidentCountLastYear = 9,
            blocksMultiRegion = true,
            blocksScale = true,
            hasAutomatedTests = false
        )
        val debt = KexGovernanceFunctions.computeSystemicTechDebtScore(auditInput)
        assertTrue(debt.techDebtScore >= 80)
        assertEquals("CRITICAL", debt.growthBlockingFactor)
        assertEquals(220000.0, debt.annualMaintenanceDragUsd, 0.001)

        val executiveReport = KexGovernanceFunctions.formulateExecutiveModernizationJustification(
            debts = listOf(debt),
            availableEngineeringBudgetUsd = 1000000.0
        )
        assertEquals(1, executiveReport.highestRiskBlockers.size)
        assertTrue(executiveReport.executiveSummary.contains("EXECUTIVE JUSTIFICATION"))
    }

    @Test
    fun `test recordGovernanceReceiptInRoom software function commits empirical receipt`() = runBlocking {
        val payload = org.json.JSONObject().apply {
            put("action", "CONVENE_ARB_TEST")
            put("result", "PASS")
            put("allocated_capital_usd", 750000.0)
        }
        val receipt = KexGovernanceFunctions.recordGovernanceReceiptInRoom(
            database = database,
            actionName = "UNIT_TEST_ACTION",
            payload = payload
        )

        assertNotNull(receipt)
        assertEquals(ProvenanceType.EMPIRICALLY_VERIFIED, receipt.provenanceId)

        val stored = database.diagnosticReceiptDao().getAllReceipts().first()
        assertTrue(stored.any { it.taskId == receipt.taskId })
    }
}

