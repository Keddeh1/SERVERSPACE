package com.example

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import com.example.ChatMessage
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
class BrainkFunctionalTest {

    private lateinit var viewModel: ChatViewModel

    @Before
    fun setup() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        viewModel = ChatViewModel(app)
    }

    @Test
    fun `test help command returns valid command list`() = runTest {
        viewModel.sendMessage("help")
        
        val messages = viewModel.messages.value
        val lastMessage = messages.last()
        
        assertTrue("Help response should contain 'boot'", lastMessage.text.contains("boot"))
        assertTrue("Help response should contain 'inject'", lastMessage.text.contains("inject"))
        assertTrue("Help response should contain 'infer'", lastMessage.text.contains("infer"))
    }

    @Test
    fun `test boot command executes VFD loop`() = runTest {
        // Default seed
        viewModel.sendMessage("boot")
        
        val messages = viewModel.messages.value
        val lastMessage = messages.last()
        
        assertTrue("Boot should be successful", lastMessage.text.contains("BOOT SEQUENCE SUCCESSFUL"))
        assertTrue("Should show VFD length", lastMessage.text.contains("106977 digits"))
    }

    @Test
    fun `test model injection switches active provider`() = runTest {
        val testUrl = "https://api.together.xyz"
        val testKey = "test_key"
        val testMdl = "mistralai/Mistral-7B-Instruct-v0.2"
        
        viewModel.sendMessage("inject $testUrl $testKey $testMdl")
        
        val messages = viewModel.messages.value
        val lastMessage = messages.last()
        
        assertTrue("Injection should be successful", lastMessage.text.contains("MODEL INJECTION SUCCESSFUL"))
        
        val activeProvider = viewModel.activeProvider.value
        assertTrue("Provider should be OpenSource", activeProvider is OpenSourceProvider)
        assertTrue("Provider name should contain model", activeProvider.name.contains(testMdl))
    }

    @Test
    fun `test status command reports system telemetry`() = runTest {
        viewModel.sendMessage("boot")
        viewModel.sendMessage("status")
        
        val messages = viewModel.messages.value
        val lastMessage = messages.last()
        
        assertTrue("Status should show boot state", lastMessage.text.contains("ACTIVE_RUNTIME"))
        assertTrue("Status should show PLL lock", lastMessage.text.contains("true"))
    }
}
