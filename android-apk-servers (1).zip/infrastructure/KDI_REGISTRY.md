# KEDDEH DEPLOYMENT INFRASTRUCTURE REGISTRY

## KDI Node Registry

### Node: server://dns-alpha
- **Status**: PROVISIONING
- **Capability Vector**:
    - compute: BOUND (BIND9-Node-1)
    - storage: BOUND (BIND9-Zone-Data)
    - net: BOUND (Anycast-BGP)
    - dns: AUTHORITATIVE
    - tls: AVAILABLE
    - http: AVAILABLE
    - process: AVAILABLE
    - container: AVAILABLE
    - auth: AVAILABLE
    - persistence: AVAILABLE
    - observation: AVAILABLE
    - execution: AVAILABLE

### Node: server://dns-beta
- **Status**: PROVISIONING
- **Capability Vector**:
    - compute: BOUND (BIND9-Node-2)
    - storage: BOUND (BIND9-Zone-Data)
    - net: BOUND (Anycast-BGP)
    - dns: AUTHORITATIVE
    - tls: AVAILABLE
    - http: AVAILABLE
    - process: AVAILABLE
    - container: AVAILABLE
    - auth: AVAILABLE
    - persistence: AVAILABLE
    - observation: AVAILABLE
    - execution: AVAILABLE
