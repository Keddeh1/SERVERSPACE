# Terraform Infrastructure for Enterprise DNS Server
# Provider: AWS (Example Baseline)

provider "aws" {
  region = "us-east-1"
}

resource "aws_instance" "dns_node" {
  count         = 2
  ami           = "ami-0c7217cdde317cfec" # Ubuntu 24.04 LTS
  instance_type = "c6g.2xlarge"           # 8 vCPU, 16 GB RAM (Graviton optimized for throughput)
  
  root_block_device {
    volume_size = 50
    volume_type = "gp3" # NVMe SSD
  }

  tags = {
    Name = "enterprise-dns-node-${count.index}"
    Role = "authoritative-dns"
  }
}
