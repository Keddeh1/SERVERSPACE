# BGP Anycast Configuration (Blueprint for FRR/Bird)
# DNS-004: Network Topology & BGP/Anycast Routing

# This blueprint assumes a BGP-capable network environment.
# Routing is configured to announce the Anycast IP (e.g., 198.51.100.1)
# via BGP from all authoritative nodes.

# Example FRR configuration snippet for each node:
#
# router bgp 65000
#  bgp router-id 192.0.2.10
#  neighbor 203.0.113.1 remote-as 65001
#  !
#  address-family ipv4 unicast
#   network 198.51.100.0/24
#   neighbor 203.0.113.1 activate
#  exit-address-family
