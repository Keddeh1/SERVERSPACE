#!/bin/bash
echo "--- CODEBASE INGESTION ---"
FILES=$(find app/src/main/java/com/example -name "*.kt" | wc -l)
LINES=$(cat $(find app/src/main/java/com/example -name "*.kt") | wc -l)
echo "Files Assessed: $FILES"
echo "Logic Lines: $LINES"
echo "--- HARDWARE INGESTION ---"
echo "Logical Processors: $(nproc)"
echo "Memory: $(free -m | grep Mem | awk '{print $2}') MB"
