fun main() {
    val key = 4696753037434160968L
    val doubleVal = Double.fromBits(key)
    println(doubleVal)
}
