import math, hashlib
key = 4696753037434160968
hex_str = f"{key:016x}"
byte_array = [int(hex_str[i:i+2], 16) for i in range(0, 16, 2)]

version = f"{chr(byte_array[0])}{chr(byte_array[1])}{chr(byte_array[2])}"
bypass_index = byte_array[6]
anchor = chr(byte_array[7])

sign = (key >> 63) & 1
exponent = (key >> 52) & 0x7FF
fraction = key & 0xFFFFFFFFFFFFF
if exponent == 0:
    float_val = ((-1)**sign) * (fraction / (2**52)) * (2**-1022)
else:
    float_val = ((-1)**sign) * (1 + fraction / (2**52)) * (2**(exponent - 1023))

lanes_MATH = byte_array[7] - 64
lanes_LEDGER = 1
lanes_CODE = math.floor(float_val / 10000)

n_max = 10000
bypass = bypass_index
log_P = sum(math.log10(k) for k in range(2, n_max + 1)) - math.log10(bypass + 1)

math_len = math.floor(math.log10(lanes_MATH) + log_P) + 1
ledger_len = math.floor(math.log10(lanes_LEDGER) + log_P) + 1
code_len = math.floor(math.log10(lanes_CODE) + log_P) + 1
final_strand_length = (math_len + ledger_len + code_len) - 3

lanes_MATH *= -1
lanes_LEDGER *= -1
lanes_CODE *= -1

state_signature = f"{lanes_MATH}:{lanes_LEDGER}:{lanes_CODE}:{final_strand_length}"
silicon_anchor_hash = hashlib.sha256(state_signature.encode('utf-8')).hexdigest()

print(f"final_strand_length: {final_strand_length}")
print(f"silicon_anchor_hash: {silicon_anchor_hash}")
