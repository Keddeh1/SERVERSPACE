import math
import hashlib

key = 4696753037434160968
hex_str = f"{key:016x}"
byte_array = [int(hex_str[i:i+2], 16) for i in range(0, 16, 2)]

version = f"{chr(byte_array[0])}{chr(byte_array[1])}{chr(byte_array[2])}"
bypass_index = byte_array[6]
anchor = chr(byte_array[7])

sign = (key >> 63) & 1
exponent = (key >> 52) & 0x7FF
fraction = key & 0xFFFFFFFFFFFFF

if exponent == 0:
    float_val = ((-1)**sign) * (fraction / (2**52)) * (2**-1022)
else:
    float_val = ((-1)**sign) * (1 + fraction / (2**52)) * (2**(exponent - 1023))

print(f"version: {version}, bypass_index: {bypass_index}, anchor: {anchor}, float_val: {float_val}")

