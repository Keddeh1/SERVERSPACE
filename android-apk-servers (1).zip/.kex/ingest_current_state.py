
import sys
import json
from pathlib import Path
from kex_state_kernel import (
    KexState, MaturityStage, SeedAuthority, A8_AUTHORITY, 
    VolumeState, MultiplexState, StateSnapshot, StateStore, 
    canonical_json, digest
)
import time

def ingest_current_state():
    root = Path(".")
    
    # 1. Define Volumes based on reality
    volumes = [
        VolumeState(
            identity="architecture",
            kex_state=KexState.ACTIVE,
            maturity=MaturityStage.IMPLEMENTED,
            authority_identity=A8_AUTHORITY.authority_identity,
            payload={"description": "Active KEX Kernel with deterministic registry"}
        ),
        VolumeState(
            identity="source",
            kex_state=KexState.ACTIVE,
            maturity=MaturityStage.EXECUTED,
            authority_identity=A8_AUTHORITY.authority_identity,
            payload={"description": "Kotlin/Compose codebase with KexKernel"}
        ),
        VolumeState(
            identity="deployment",
            kex_state=KexState.PRE_TRANSLATION,
            maturity=MaturityStage.IMPLEMENTED,
            authority_identity=A8_AUTHORITY.authority_identity,
            payload={"description": "Candidate build configuration"}
        ),
        # Add other volumes as needed
    ]
    
    multiplex = MultiplexState(volumes=tuple(volumes))
    
    # 2. Create Snapshot
    snapshot = StateSnapshot(
        state_position=1,
        state_identity=digest({"initial": "state"}),
        previous_state_identity=None,
        seed_authority_identity=A8_AUTHORITY.authority_identity,
        seed_digest=A8_AUTHORITY.verify()["seed_digest"],
        multiplex=multiplex,
        transition_identity="TRANSITION_INITIAL_INGESTION",
        evidence_root=digest("INITIAL_EVIDENCE"),
        committed_at_ns=time.time_ns()
    )
    
    return snapshot

if __name__ == "__main__":
    store = StateStore(Path(".kex"))
    snapshot = ingest_current_state()
    store.save(snapshot)
    print(f"State 1 committed: {snapshot.state_identity}")
