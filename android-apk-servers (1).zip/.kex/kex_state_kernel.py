
import hashlib
import json
import os
import tempfile
import time
from dataclasses import dataclass, field, asdict
from enum import IntEnum, Enum
from pathlib import Path
from typing import Any, Mapping, Sequence

# ---------------------------------------------------------
# KEX EXECUTABLE STATE DOMAIN
# ---------------------------------------------------------

class KexState(IntEnum):
    ISOLATED = -3
    PRE_TRANSLATION = -2
    SINGULAR = 1
    ACTIVE = 2
    RESOLVED = 3


class MaturityStage(str, Enum):
    POPULATED = "POPULATED"
    TESTED_INITIAL = "TESTED_INITIAL"
    IMPLEMENTED = "IMPLEMENTED"
    TESTED_IMPLEMENTED = "TESTED_IMPLEMENTED"
    OPTIMISED = "OPTIMISED"
    EXECUTED = "EXECUTED"
    MAINTAINED = "MAINTAINED"
    OPERATING = "OPERATING"


MATURITY_ORDER: tuple[MaturityStage, ...] = (
    MaturityStage.POPULATED,
    MaturityStage.TESTED_INITIAL,
    MaturityStage.IMPLEMENTED,
    MaturityStage.TESTED_IMPLEMENTED,
    MaturityStage.OPTIMISED,
    MaturityStage.EXECUTED,
    MaturityStage.MAINTAINED,
    MaturityStage.OPERATING,
)


def canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()

@dataclass(frozen=True)
class InformationAddress:
    source_identity: str
    positions: tuple[int, ...]

    def __post_init__(self) -> None:
        if not self.source_identity:
            raise ValueError("SOURCE_IDENTITY_REQUIRED")

        if not self.positions:
            raise ValueError("LOCAL_INFORMATION_POSITION_REQUIRED")

        for position in self.positions:
            if position < 1:
                raise ValueError(
                    "KEX_INFORMATION_POSITIONS_MUST_BE_ONE_ORIGIN"
                )

    def child(self, local_position: int = 1) -> "InformationAddress":
        if local_position < 1:
            raise ValueError("LOCAL_POSITION_MUST_BEGIN_AT_ONE")

        return InformationAddress(
            source_identity=self.source_identity,
            positions=self.positions + (local_position,),
        )

    @property
    def where(self) -> str:
        return self.source_identity

    @property
    def where_is(self) -> tuple[int, ...]:
        return self.positions

@dataclass(frozen=True)
class SeedAuthority:
    authority_identity: str
    seed_decimal: int
    expected_prefix: str
    expected_anchor: str
    expected_release_position: int
    expected_bypass_position: int

    def ordered_bytes(self) -> tuple[int, ...]:
        raw = self.seed_decimal.to_bytes(8, "big", signed=False)
        return tuple(raw)

    def verify(self) -> dict[str, Any]:
        raw = self.ordered_bytes()

        prefix = bytes(raw[:3]).decode("ascii")
        anchor = chr(raw[-1])

        checks = {
            "prefix": prefix == self.expected_prefix,
            "anchor": anchor == self.expected_anchor,
            "one_origin_positions": all(
                position >= 1
                for position, _ in enumerate(raw, start=1)
            ),
        }

        return {
            "valid": all(checks.values()),
            "authority_identity": self.authority_identity,
            "checks": checks,
            "seed_digest": digest({
                "authority": self.authority_identity,
                "seed_decimal": self.seed_decimal,
                "bytes": raw,
            }),
        }


A8_AUTHORITY = SeedAuthority(
    authority_identity="KEX_SEED_A8_COGNITIVE_INTEGRITY",
    seed_decimal=4696753037434160968,
    expected_prefix="A.8",
    expected_anchor="H",
    expected_release_position=3,
    expected_bypass_position=7,
)

@dataclass(frozen=True)
class VolumeState:
    identity: str
    kex_state: KexState
    maturity: MaturityStage
    authority_identity: str
    payload: Mapping[str, Any]
    blockers: tuple[str, ...] = ()
    evidence_ids: tuple[str, ...] = ()

    def canonical_form(self) -> dict[str, Any]:
        return {
            "identity": self.identity,
            "kex_state": int(self.kex_state),
            "maturity": self.maturity.value,
            "authority_identity": self.authority_identity,
            "payload": dict(self.payload),
            "blockers": list(self.blockers),
            "evidence_ids": list(self.evidence_ids),
        }


@dataclass(frozen=True)
class MultiplexState:
    volumes: tuple[VolumeState, ...]

    def __post_init__(self) -> None:
        identities = [volume.identity for volume in self.volumes]

        if len(identities) != len(set(identities)):
            raise ValueError("DUPLICATE_MULTIPLEX_VOLUME")

    def get(self, identity: str) -> VolumeState:
        for volume in self.volumes:
            if volume.identity == identity:
                return volume

        raise KeyError(identity)

    def canonical_form(self) -> list[dict[str, Any]]:
        return [
            volume.canonical_form()
            for volume in sorted(
                self.volumes,
                key=lambda value: value.identity,
            )
        ]

class EvidenceClass(str, Enum):
    SOURCE = "SOURCE"
    TEST = "TEST"
    FORMAL = "FORMAL"
    BENCHMARK = "BENCHMARK"
    EXECUTION = "EXECUTION"
    MAINTENANCE = "MAINTENANCE"
    OPERATING = "OPERATING"
    EXTERNAL_AUTHORITY = "EXTERNAL_AUTHORITY"


@dataclass(frozen=True)
class EvidenceReceipt:
    evidence_identity: str
    evidence_class: EvidenceClass
    subject_identity: str
    passed: bool
    producer_identity: str
    input_digest: str
    output_digest: str
    metadata: Mapping[str, Any]

    def canonical_form(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "evidence_class": self.evidence_class.value,
            "metadata": dict(self.metadata),
        }

@dataclass(frozen=True)
class StateSnapshot:
    state_position: int
    state_identity: str
    previous_state_identity: str | None

    seed_authority_identity: str
    seed_digest: str

    multiplex: MultiplexState

    transition_identity: str
    evidence_root: str

    committed_at_ns: int

    def __post_init__(self) -> None:
        if self.state_position < 1:
            raise ValueError("STATE_POSITION_MUST_BEGIN_AT_ONE")

@dataclass
class ExecutionTransaction:
    transaction_identity: str
    source_state_identity: str
    transition: "TransitionSpecification"

    proposed_payload: dict[str, Any] = field(default_factory=dict)
    evidence: list[EvidenceReceipt] = field(default_factory=list)

    started_at_ns: int = field(default_factory=time.time_ns)

    committed: bool = False
    aborted: bool = False

    def add_evidence(self, receipt: EvidenceReceipt) -> None:
        if self.committed or self.aborted:
            raise RuntimeError("TRANSACTION_CLOSED")

        self.evidence.append(receipt)

    def abort(self) -> None:
        if self.committed:
            raise RuntimeError("COMMITTED_TRANSACTION_CANNOT_ABORT")

        self.aborted = True

class StateStore:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.snapshots = root / "snapshots"
        self.ledger = root / "transitions.jsonl"
        self.current_pointer = root / "CURRENT"

        self.snapshots.mkdir(parents=True, exist_ok=True)

    def _snapshot_path(self, state_identity: str) -> Path:
        return self.snapshots / f"{state_identity}.json"

    def save(self, snapshot: StateSnapshot) -> None:
        payload = {
            "state_position": snapshot.state_position,
            "state_identity": snapshot.state_identity,
            "previous_state_identity": snapshot.previous_state_identity,
            "seed_authority_identity": snapshot.seed_authority_identity,
            "seed_digest": snapshot.seed_digest,
            "multiplex": snapshot.multiplex.canonical_form(),
            "transition_identity": snapshot.transition_identity,
            "evidence_root": snapshot.evidence_root,
            "committed_at_ns": snapshot.committed_at_ns,
        }

        target = self._snapshot_path(snapshot.state_identity)

        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=self.snapshots,
            delete=False,
        ) as handle:
            handle.write(canonical_json(payload))
            handle.flush()
            os.fsync(handle.fileno())
            temporary = Path(handle.name)

        temporary.replace(target)

        pointer_tmp = self.root / ".CURRENT.tmp"
        pointer_tmp.write_text(
            snapshot.state_identity,
            encoding="utf-8",
        )

        pointer_tmp.replace(self.current_pointer)

    def load_current(self) -> dict[str, Any] | None:
        if not self.current_pointer.exists():
            return None

        state_identity = self.current_pointer.read_text(
            encoding="utf-8"
        ).strip()

        path = self._snapshot_path(state_identity)

        if not path.exists():
            raise RuntimeError("CURRENT_STATE_TARGET_MISSING")

        return json.loads(path.read_text(encoding="utf-8"))

class RehydrationEngine:
    def __init__(
        self,
        state_store: StateStore,
        seed_authority: SeedAuthority,
    ) -> None:
        self.state_store = state_store
        self.seed_authority = seed_authority

    def rehydrate(self) -> dict[str, Any]:
        seed_receipt = self.seed_authority.verify()

        if not seed_receipt["valid"]:
            raise RuntimeError("SEED_AUTHORITY_VERIFICATION_FAILED")

        snapshot = self.state_store.load_current()

        if snapshot is None:
            return {
                "status": "SEED_READY_NO_COMMITTED_STATE",
                "seed": seed_receipt,
                "next_state_position": 1,
            }

        if (
            snapshot["seed_authority_identity"]
            != self.seed_authority.authority_identity
        ):
            raise RuntimeError("STATE_SEED_AUTHORITY_MISMATCH")

        if snapshot["seed_digest"] != seed_receipt["seed_digest"]:
            raise RuntimeError("STATE_SEED_DIGEST_MISMATCH")

        return {
            "status": "STATE_REHYDRATED",
            "seed": seed_receipt,
            "snapshot": snapshot,
            "next_state_position":
                int(snapshot["state_position"]) + 1,
        }
