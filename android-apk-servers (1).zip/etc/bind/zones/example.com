$TTL    3600
@       IN      SOA     ns1.example.com. admin.example.com. (
                              2026081401 ; Serial (YYYYMMDDNN)
                              7200       ; Refresh (2 hours)
                              3600       ; Retry (1 hour)
                              1209600    ; Expire (2 weeks)
                              3600       ; Minimum TTL (1 hour)
                              )

; --- Authoritative Name Servers ---
@       IN      NS      ns1.example.com.
@       IN      NS      ns2.example.com.

; --- A/AAAA Records for Infrastructure ---
ns1     IN      A       192.0.2.10
ns1     IN      AAAA    2001:db8::10
ns2     IN      A       198.51.100.10
ns2     IN      AAAA    2001:db8:1::10

; --- Core Domain Records ---
@       IN      A       203.0.113.50
@       IN      AAAA    2001:db8:2::50
www     IN      CNAME   @

; --- Enterprise Mail (MX) & Security ---
@       IN      MX  10  mail.example.com.
mail    IN      A       203.0.113.25
@       IN      TXT     "v=spf1 ip4:203.0.113.25 -all"
