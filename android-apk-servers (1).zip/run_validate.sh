#!/bin/bash
# Mock script just for output emulation on the agent side
echo "Triggering validate command..."
