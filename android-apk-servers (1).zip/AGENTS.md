# Agent Instructions

## KEX Architectural Invariants (MANDATORY)

You MUST operate under the following architectural rules for all code-space modifications:

1. **Epistemic Enforcement Pipeline**: All data entering the agent's context must be typed by provenance: `DECLARED` (unverified intent), `INFERRED` (deduced logic), or `EMPIRICALLY_VERIFIED` (empirical receipt required for production).
2. **Fail-Closed Governance**: No deployment or production state change is permitted without passing all sequential gates in the **Fail-Closed Gate Matrix ($G_0$ to $G_8$)**.
3. **Executable Volume Architecture**: Minimize physical storage footprint by preferring **Generative Mappings** over **Literal Data Storage**. Use logical namespace addressing and rules to represent vast virtual volumes within the constrained physical 1GB envelope.
